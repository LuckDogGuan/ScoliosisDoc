#include <flutter/dart_project.h>
#include <flutter/flutter_view_controller.h>
#include <windows.h>
#include <iostream>

#include "flutter_window.h"
#include "utils.h"

int APIENTRY wWinMain(_In_ HINSTANCE instance, _In_opt_ HINSTANCE prev,
                      _In_ wchar_t *command_line, _In_ int show_command) {
  // Report this launch even if initialization or the single-instance check fails.
  if (!::AttachConsole(ATTACH_PARENT_PROCESS) && ::IsDebuggerPresent()) {
    CreateAndAttachConsole();
  }
  std::cout << "scoliosis.process=" << ::GetCurrentProcessId() << std::endl;
  // Keep this handle alive for the whole process lifetime.
  HANDLE single_instance = ::CreateMutexW(
      nullptr, FALSE, L"Local\\ScoliosisFlutter_8C884687_18C6_4A5D_AA54_86F82B98B457");
  if (single_instance == nullptr) {
    ::MessageBoxW(nullptr, L"\u7A0B\u5E8F\u65E0\u6CD5\u542F\u52A8\uFF0C\u8BF7\u91CD\u8BD5\u3002",
                  L"\u810A\u67F1\u4FA7\u5F2F\u7B5B\u67E5", MB_OK | MB_ICONERROR);
    return EXIT_FAILURE;
  }
  if (::GetLastError() == ERROR_ALREADY_EXISTS) {
    ::MessageBoxW(nullptr, L"\u7A0B\u5E8F\u5DF2\u5728\u8FD0\u884C\uFF0C\u8BF7\u5207\u6362\u5230\u5DF2\u6253\u5F00\u7684\u7A97\u53E3\u3002",
                  L"\u810A\u67F1\u4FA7\u5F2F\u7B5B\u67E5", MB_OK | MB_ICONINFORMATION);
    ::CloseHandle(single_instance);
    return EXIT_SUCCESS;
  }

  // Initialize COM, so that it is available for use in the library and/or
  // plugins.
  ::CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);

  flutter::DartProject project(L"data");

  std::vector<std::string> command_line_arguments =
      GetCommandLineArguments();

  project.set_dart_entrypoint_arguments(std::move(command_line_arguments));

  FlutterWindow window(project);
  Win32Window::Point origin(10, 10);
  Win32Window::Size size(1280, 720);
  if (!window.Create(L"\u810A\u67F1\u4FA7\u5F2E\u7B5B\u67E5", origin, size)) {
    return EXIT_FAILURE;
  }
  window.SetQuitOnClose(true);

  ::MSG msg;
  while (::GetMessage(&msg, nullptr, 0, 0)) {
    ::TranslateMessage(&msg);
    ::DispatchMessage(&msg);
  }

  ::CoUninitialize();
  ::CloseHandle(single_instance);
  return EXIT_SUCCESS;
}
