import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:scoliosis_flutter/app/app_controller.dart';
import 'package:scoliosis_flutter/audio/name_speaker.dart';
import 'package:scoliosis_flutter/roster/roster.dart';
import 'package:scoliosis_flutter/survey/survey.dart';
import 'package:scoliosis_flutter/roster/student.dart';

class Speaker implements NameSpeaker {
  final phrases = <String>[];
  @override
  Future<void> speak(String text) async {
    phrases.add(text);
  }

  @override
  Future<void> stop() async {}
}

final roster = List.generate(
  5,
  (i) => Student(
    id: '$i',
    school: '回归',
    grade: '一年级',
    klass: '一班',
    studentNo: '${i + 1}',
    name: '学生$i',
    gender: i == 4 ? '男' : '女',
  ),
);

Future<void> waitFor(bool Function() condition) async {
  for (var i = 0; i < 100; i++) {
    if (condition()) return;
    await Future<void>.delayed(const Duration(milliseconds: 20));
  }
  fail('asynchronous condition did not complete');
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  HttpOverrides.global = null;

  test(
    'Windows TTS never awaits native completion and cancels stale requests',
    () async {
      final calls = <MethodCall>[];
      const channel = MethodChannel('flutter_tts');
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(channel, (call) async {
            calls.add(call);
            if (call.method == 'getVoices') {
              return [
                {'name': 'Microsoft Huihui', 'locale': 'zh-CN'},
              ];
            }
            return 1;
          });
      addTearDown(
        () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
            .setMockMethodCallHandler(channel, null),
      );
      final speaker = WindowsSapiSpeaker();
      await speaker.speak('首次试听');
      expect(calls.first.method, 'awaitSpeakCompletion');
      expect(calls.first.arguments, false);
      final a = speaker.speak('旧叫号');
      final b = speaker.stop();
      await Future.wait([a, b]);
      expect(calls.where((c) => c.method == 'getVoices').length, 1);
      expect(calls.where((c) => c.method == 'speak').length, 1);
    },
  );

  test(
    'gender selection persists and prepared records never enter history',
    () async {
      final root = Directory(
        'build/capture-fixes-gender-${DateTime.now().microsecondsSinceEpoch}',
      );
      final app = AppController(root, speaker: Speaker())
        ..students = roster
        ..schoolFilter = '回归'
        ..gradeFilter = '一年级'
        ..classFilter = '一班'
        ..selectedStudentId = '4';
      addTearDown(app.dispose);
      app.setCaptureGender(CaptureGender.female);
      await app.setSkipped('2', true);
      expect(app.selectedStudentId, '0');
      expect(app.captureStudents.map((s) => s.id), ['0', '1', '2', '3']);
      expect(app.searchStudents('学生').map((s) => s.id), ['0', '1', '2', '3']);
      final session = await SurveySession.open(
        root,
        '回归',
        roster,
        DateTime.now(),
      );
      app.sessions.add(session);
      await session.prepareCapture('CAM', 'CAM-a', 'gate', roster[0]);
      expect(app.historyFor('0'), isEmpty);
      app.capturePermission = true;
      expect(app.exitBlocked, true);
      await session.cancelPrepared('CAM');
      app.capturePermission = false;
      expect(app.historyFor('0'), isEmpty);
      expect(app.exitBlocked, false);
      final restored = AppController(root, speaker: Speaker())
        ..students = roster;
      addTearDown(restored.dispose);
      await restored.loadUiForTest();
      expect(restored.captureGender, CaptureGender.female);
      expect(restored.operationsFor('2').single['action'], 'skip');
    },
  );

  test(
    'fixed queue, skipped restore positions, zero timer, duplicate events and class completion',
    () async {
      final socket = await RawDatagramSocket.bind(
        InternetAddress.loopbackIPv4,
        37020,
      );
      final root = Directory(
        'build/capture-fixes-flow-${DateTime.now().microsecondsSinceEpoch}',
      );
      final speaker = Speaker();
      final app = AppController(root, speaker: speaker);
      final controls = <Map<String, dynamic>>[];
      String gate = '', prepared = '';
      var startOnDisable = false;
      socket.listen((event) async {
        if (event != RawSocketEvent.read) return;
        final packet = socket.receive();
        if (packet == null) return;
        Map<String, dynamic> request;
        try {
          request = jsonDecode(utf8.decode(packet.data));
        } catch (_) {
          return;
        }
        final op = request['op'];
        if (op == null) return;
        controls.add(request);
        if (op == 'capture_enable') gate = request['gate_id'];
        if (op == 'capture_prepare') prepared = request['capture_id'];
        if (op == 'capture_disable' && startOnDisable) {
          startOnDisable = false;
          // An already admitted start can finish persisting during disable.
          final session = app.sessions.firstWhere(
            (s) => s.captureGates[prepared] == gate,
          );
          await session.startPrepared('CAM', prepared, gate);
        }
        socket.send(
          utf8.encode(
            jsonEncode({
              ...request,
              'op': op == 'hello_query' ? 'hello_reply' : '${op}_reply',
              'ok': true,
              'boot_id': 'boot',
              'phase': 'idle',
              'paired_host_id': app.devices.hostId,
              'capabilities': [
                'capture_gate',
                'capture_prepare',
                'capture_events',
                'upload_grant',
                'pair_transaction',
              ],
              'items': [],
              'next_offset': -1,
            }),
          ),
          packet.address,
          packet.port,
        );
      });
      addTearDown(() async {
        await app.shutdown();
        app.dispose();
        socket.close();
      });
      await saveMasterRoster(root, roster);
      await app.initialize(serverPort: 0);
      await app.devices.pairAsCurrent('CAM');
      final device = app.devices.put('CAM')
        ..ip = '127.0.0.1'
        ..bootId = 'boot'
        ..pairedHostId = app.devices.hostId
        ..lastHello = DateTime.now()
        ..capabilities = {
          'capture_gate',
          'capture_prepare',
          'capture_events',
          'upload_grant',
          'pair_transaction',
        };
      app
        ..schoolFilter = '回归'
        ..gradeFilter = '一年级'
        ..classFilter = '一班'
        ..selectedStudentId = '0';
      app.setCaptureGender(CaptureGender.female);
      expect(await app.startCapture(), isNull);
      await waitFor(() => speaker.phrases.isNotEmpty);
      expect(speaker.phrases.first, '一年级一班，第一位，学生0');
      final oldId = prepared;
      app.selectStudent('3'); // Browsing does not change the skip target.
      await app.setSkipped(app.preparedStudent!.id, true);
      expect(app.preparedStudent!.id, '1');
      expect(
        app.sessions
            .expand((s) => s.capturePhases.entries)
            .firstWhere((e) => e.key == oldId)
            .value,
        'cancelled',
      );
      await app.setSkipped('0', false); // Passed position goes to the tail.
      await app.setSkipped('2', true);
      await app.setSkipped('2', false); // Future position keeps original order.
      app.setCaptureGender(CaptureGender.male); // Frozen run remains girls.

      final client = HttpClient();
      addTearDown(() => client.close(force: true));
      Future<Map<String, dynamic>> post(
        String path,
        Map<String, dynamic> data,
      ) async {
        final request = await client.postUrl(
          Uri.parse(
            'http://127.0.0.1:${app.server!.port}/api/v1/capture/$path',
          ),
        );
        request.headers.contentType = ContentType.json;
        request.write(jsonEncode(data));
        final response = await request.close();
        final result =
            jsonDecode(await utf8.decoder.bind(response).join())
                as Map<String, dynamic>;
        expect(response.statusCode, 200, reason: '$result');
        return result;
      }

      for (final studentId in ['1', '2', '3', '0']) {
        await waitFor(
          () =>
              app.preparedStudent?.id == studentId &&
              controls.lastWhere(
                    (c) => c['op'] == 'capture_prepare',
                  )['capture_id'] ==
                  prepared,
        );
        expect(app.preparedStudent!.gender, '女');
        app.selectStudent(studentId);
        final id = prepared;
        final body = <String, dynamic>{
          'version': 3,
          'device_id': 'CAM',
          'capture_id': id,
          'gate_id': gate,
          'boot_id': 'boot',
        };
        await post('start', body);
        await post('status', {
          ...body,
          'phase': 'recording',
          'started_at_ms': DateTime.now()
              .subtract(const Duration(seconds: 20))
              .millisecondsSinceEpoch,
        });
        expect(app.shot.elapsed, 0); // A deliberately skewed board clock.
        if (studentId == '1') {
          app.selectStudent('4');
          await Future<void>.delayed(const Duration(milliseconds: 1100));
          app.selectStudent(studentId);
          expect(app.shot.elapsed, greaterThanOrEqualTo(1));
        }
        expect(app.exitBlocked, true);
        await app.setSkipped(studentId, true);
        expect(app.isSkipped(studentId), false); // Recording owns the target.
        final completion = {
          ...body,
          'phase': 'completed',
          'event_id': 'done-$id',
          'result': 'success',
          'duration_ms': 3000,
          'stop_reason': 'released',
          'started_at_ms': 1000,
          'ended_at_ms': 4000,
        };
        await post('status', completion);
        await waitFor(
          () => studentId == '0' ? !app.capturePermission : prepared != id,
        );
        await waitFor(
          () =>
              speaker.phrases.last ==
              (studentId == '0'
                  ? '完成一年级一班4人的拍摄，跳过0人'
                  : '下一位，学生${studentId == '1'
                        ? '2'
                        : studentId == '2'
                        ? '3'
                        : '0'}'),
        );
        final count = speaker.phrases.length;
        await post('status', completion);
        await Future<void>.delayed(const Duration(milliseconds: 50));
        expect(speaker.phrases.length, count);
      }
      expect(speaker.phrases.last, '完成一年级一班4人的拍摄，跳过0人');
      expect(app.capturePermission, false);
      device.capturePhase = 'idle';
      expect(app.exitBlocked, false);
      await app.setSkipped('4', true);
      await app.setSkipped('4', false);
      expect(app.capturePermission, false); // Undo after ending never restarts.
      expect(app.operationsFor('4').map((e) => e['action']), ['skip', 'clear']);
      app.selectStudent('4');
      expect(await app.startCapture(), isNull);
      final raceId = prepared;
      startOnDisable = true;
      await app.setSkipped('4', true);
      expect(app.isSkipped('4'), false);
      expect(app.capturePermission, false);
      expect(app.recordingBusy, true);
      expect(app.exitBlocked, true);
      expect(prepared, raceId); // Never advance or replace the admitted target.
      await post('status', {
        'version': 3,
        'device_id': 'CAM',
        'capture_id': raceId,
        'gate_id': gate,
        'boot_id': 'boot',
        'phase': 'completed',
        'event_id': 'race-$raceId',
        'result': 'success',
        'duration_ms': 3000,
        'stop_reason': 'released',
        'started_at_ms': 1000,
        'ended_at_ms': 4000,
      });
      expect(app.recordingBusy, false);
      expect(app.exitBlocked, false);
      expect(
        app.sessions
            .expand((s) => s.completionEvents.values)
            .firstWhere((e) => e['captureId'] == raceId)['studentId'],
        '4',
      );
    },
  );
}
