import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:scoliosis_flutter/app/app_controller.dart';
import 'package:scoliosis_flutter/main.dart';

void main() {
  testWidgets(
    'close blocks capture, deduplicates requests, cancels and confirms',
    (tester) async {
      final root = Directory(
        'build/window-close-${DateTime.now().microsecondsSinceEpoch}',
      );
      var approved = 0;
      const channel = MethodChannel('scoliosis/window');
      tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(channel, (
        call,
      ) async {
        if (call.method == 'approveClose') approved++;
        return null;
      });
      addTearDown(
        () => tester.binding.defaultBinaryMessenger.setMockMethodCallHandler(
          channel,
          null,
        ),
      );
      await tester.pumpWidget(MaterialApp(home: HomeShell(dataRoot: root)));
      final controller =
          (tester.state(find.byType(HomeShell)) as dynamic).controller
              as AppController;
      await tester.runAsync(() async {
        for (var i = 0; i < 100 && controller.status == '正在启动'; i++) {
          await Future<void>.delayed(const Duration(milliseconds: 30));
        }
      });
      void close() =>
          tester.binding.defaultBinaryMessenger.handlePlatformMessage(
            'scoliosis/window',
            const StandardMethodCodec().encodeMethodCall(
              const MethodCall('requestClose'),
            ),
            (_) {},
          );
      controller.capturePermission = true;
      close();
      close();
      await tester.pumpAndSettle();
      expect(find.text('请先停止拍摄'), findsOneWidget);
      expect(approved, 0);
      await tester.tap(find.text('知道了'));
      await tester.pumpAndSettle();
      controller.capturePermission = false;
      close();
      await tester.pumpAndSettle();
      expect(find.text('确认关闭应用？'), findsOneWidget);
      await tester.tap(find.text('取消'));
      await tester.pumpAndSettle();
      expect(approved, 0);
      close();
      await tester.pumpAndSettle();
      await tester.tap(find.text('确认关闭'));
      await tester.runAsync(
        () => Future<void>.delayed(const Duration(milliseconds: 100)),
      );
      await tester.pump();
      expect(approved, 1);
      await tester.pumpWidget(const SizedBox());
      await tester.runAsync(controller.shutdown);
    },
  );
}
