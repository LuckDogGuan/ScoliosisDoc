import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;

import '../audio/name_speaker.dart';
import '../device/device_book.dart';
import 'error_log.dart';
import '../net/udp_discover.dart';
import '../net/device_query.dart';
import '../net/debug_bridge.dart';
import '../net/protocol_log.dart';
import '../net/instrument_server.dart';
import '../roster/roster.dart';
import '../roster/roster_sort.dart';
import '../roster/student.dart';
import '../survey/survey.dart';

enum AppPage { device, roster, capture, records }

enum CaptureMode { sequence, single }

enum CaptureGender {
  all('全部', null),
  male('只看男生', '男'),
  female('只看女生', '女');

  const CaptureGender(this.label, this.gender);
  final String label;
  final String? gender;
}

enum ShotPhase {
  idle,
  waiting,
  recording,
  finalizing,
  uploading,
  saved,
  leftOnDevice,
  failed,
}

class ShotSnapshot {
  const ShotSnapshot({
    required this.phase,
    required this.elapsed,
    required this.captureId,
    this.drill = false,
  });

  final ShotPhase phase;
  final int elapsed;
  final String? captureId;
  final bool drill;

  String get label {
    final text = switch (phase) {
      ShotPhase.idle => '待拍摄',
      ShotPhase.waiting => '等待左右键按住 1.5 秒',
      ShotPhase.recording =>
        '录制 ${elapsed.toString().padLeft(2, '0')} 秒（上限 60 秒）',
      ShotPhase.finalizing => '录像收尾中',
      ShotPhase.uploading => '上传中',
      ShotPhase.saved => '已保存到电脑',
      ShotPhase.leftOnDevice => '视频留在仪器',
      ShotPhase.failed => '拍摄失败，请检查仪器',
    };
    return drill ? '脱机演练 · $text' : text;
  }
}

class RecordRow {
  const RecordRow({
    required this.captureId,
    required this.deviceId,
    required this.time,
    required this.status,
    required this.school,
    required this.grade,
    required this.klass,
    required this.studentNo,
    required this.name,
    required this.studentId,
    required this.fileName,
    this.session,
    this.record,
  });

  final String captureId;
  final String deviceId;
  final DateTime time;
  final String status;
  final String school;
  final String grade;
  final String klass;
  final String studentNo;
  final String name;
  final String studentId;
  final String fileName;
  final SurveySession? session;
  final VideoRecord? record;
}

class AppController extends ChangeNotifier {
  AppController(this.dataRoot, {NameSpeaker? speaker})
    : _speaker = speaker ?? WindowsSapiSpeaker();

  final Directory dataRoot;
  final NameSpeaker _speaker;
  final DeviceBook devices = DeviceBook();
  List<Student> students = [];
  final List<SurveySession> sessions = [];
  InstrumentServer? server;
  Timer? _discoveryRetry;
  Timer? _queryTimer;
  bool _queryBusy = false;
  bool capturePermission = false;
  String? _gateId;
  String? _gateDeviceId;
  String? _gateBootId;
  DateTime? _gateConfirmedAt;
  final Stopwatch _leaseAge = Stopwatch();
  final Set<String> _preparedControlIds = {};
  final Set<String> _appliedCompletionEvents = {};
  Timer? _gateTimer;
  bool _renewBusy = false;
  bool _transferBusy = false;
  final Set<String> pausedUploadDevices = {};
  final Map<String, DateTime> _uploadRetryAt = {};
  final Set<String> _connectedUploadDevices = {};
  CaptureMode? _runMode;
  List<Student> _runOrder = const [];
  final Set<String> _runSuccess = {};
  final Set<String> _runSkipped = {};
  final Map<String, Stopwatch> _recordingClocks = {};
  bool _disposed = false;
  Future<void>? _shutdown;
  bool _startingCapture = false;
  bool get recordingBusy =>
      _mockRunning ||
      _startingCapture ||
      sessions.any(
        (s) =>
            s.activeCaptureId != null &&
            const {
              'starting',
              'recording',
              'finalizing',
            }.contains(s.capturePhases[s.activeCaptureId]),
      ) ||
      const {
        'starting',
        'recording',
        'finalizing',
      }.contains(devices.current?.capturePhase);
  Student? get preparedStudent => _shotSession?.armedStudent;
  bool uploadsPaused(String id) => pausedUploadDevices.contains(id);
  void setUploadsPaused(String id, bool paused) {
    if (paused) {
      pausedUploadDevices.add(id);
    } else {
      pausedUploadDevices.remove(id);
    }
    notifyListeners();
    final device = devices.devices[id];
    if (!paused && device != null) {
      unawaited(_grantPendingUploads(device));
    }
  }

  final List<({Future<void> Function() run, bool priority})> _controls = [];
  bool _controlBusy = false;
  final Map<String, int> _controlSequences = {};
  String _uniqueId(String prefix) =>
      '$prefix-${DateTime.now().microsecondsSinceEpoch}-${Random.secure().nextInt(1 << 32)}';
  bool get _gateValid =>
      capturePermission &&
      _gateConfirmedAt != null &&
      _leaseAge.elapsed < const Duration(seconds: 6);

  bool _queryStopped = false;
  int _querySequence = 0;
  String status = '正在启动';
  AppPage page = AppPage.device;
  CaptureMode captureMode = CaptureMode.sequence;
  CaptureGender captureGender = CaptureGender.all;
  bool announceNextName = true;
  Duration offlineDrillLength = const Duration(seconds: 10);
  RosterSort sort = RosterSort.studentNo;
  GenderOrder genderOrder = GenderOrder.none;
  String? schoolFilter;
  String? gradeFilter;
  String? classFilter;
  String? selectedStudentId;
  String recordStatus = '全部';
  String recordQuery = '';
  final Set<String> skippedStudentIds = {};
  final List<Map<String, String>> skipEvents = [];

  SurveySession? _shotSession;
  String? _savedBannerFor;
  bool _drillSaved = false;
  bool _mockRunning = false;
  DateTime? _mockStarted;
  String? _mockStudentId;
  Student? _mockStudentSnapshot;
  String? _mockCaptureId;
  Timer? _mockTimer;
  Completer<void>? _drillCompleter;

  @visibleForTesting
  Future<void>? get offlineDrillDone => _drillCompleter?.future;

  List<String> get schools {
    final names = students
        .map((s) => s.school)
        .where((s) => s.isNotEmpty)
        .toSet()
        .toList();
    names.sort();
    return names;
  }

  bool get hasCompleteRoster => students.any((s) => s.profileComplete);

  /// Keep diagnostics off the navigation surface.
  String get sidebarStatus {
    if (status == '正在启动') return status;
    return devices.shortStatus;
  }

  List<Student> studentsOf(String? school) =>
      students.where((s) => school == null || s.school == school).toList();

  List<String> gradesOf(String? school) {
    final names = studentsOf(
      school,
    ).map((s) => s.grade).where((s) => s.isNotEmpty).toSet().toList();
    names.sort((a, b) {
      final ar = gradeRank(a);
      final br = gradeRank(b);
      if (ar == null && br == null) return a.compareTo(b);
      if (ar == null) return 1;
      if (br == null) return -1;
      final byRank = ar.compareTo(br);
      return byRank != 0 ? byRank : a.compareTo(b);
    });
    return names;
  }

  List<String> classesOf(String? school, String? grade) {
    final names = students
        .where(
          (s) =>
              (school == null || s.school == school) &&
              (grade == null || s.grade == grade) &&
              s.klass.isNotEmpty,
        )
        .map((s) => s.klass)
        .toSet()
        .toList();
    names.sort((a, b) {
      final ar = classRank(a);
      final br = classRank(b);
      if (ar == null && br == null) return a.compareTo(b);
      if (ar == null) return 1;
      if (br == null) return -1;
      final byRank = ar.compareTo(br);
      return byRank != 0 ? byRank : a.compareTo(b);
    });
    return names;
  }

  List<Student> get classStudents {
    final visible = students
        .where(
          (s) =>
              (schoolFilter == null || s.school == schoolFilter) &&
              (gradeFilter == null || s.grade == gradeFilter) &&
              (classFilter == null || s.klass == classFilter),
        )
        .toList();
    final schools = visible.map((s) => s.school).toSet().toList()..sort();
    return [
      for (final school in schools)
        for (final scope in orderClasses(
          visible.where((s) => s.school == school),
        ))
          ...sortClass(
            visible
                .where(
                  (s) =>
                      s.school == school &&
                      s.grade == scope.grade &&
                      s.klass == scope.klass,
                )
                .toList(),
            sort,
            genderOrder,
          ),
    ];
  }

  Student? get selectedStudent =>
      students.where((s) => s.id == selectedStudentId).firstOrNull;

  int savedCount(Student student) => {
    for (final session in sessions) ...[
      for (final record in session.records)
        if (record.student?.id == student.id &&
            !record.unassigned &&
            record.captureResult == 'success')
          record.captureId,
      for (final entry in session.completionEvents.values)
        if (entry['result'] == 'success' && entry['studentId'] == student.id)
          entry['captureId'] as String,
    ],
  }.length;

  bool studentHasVideo(String id) => sessions.any(
    (session) => session.records.any((record) => record.student?.id == id),
  );

  bool isSkipped(String studentId) => skippedStudentIds.contains(studentId);

  List<Student> get captureStudents =>
      classStudents.where(_captureVisible).toList();
  bool _captureVisible(Student student) =>
      captureGender.gender == null || student.gender == captureGender.gender;

  void setCaptureGender(CaptureGender value) {
    captureGender = value;
    final selected = selectedStudent;
    if (!captureBusy && (selected == null || !_captureVisible(selected))) {
      selectedStudentId = captureStudents.firstOrNull?.id;
    }
    notifyListeners();
    unawaited(_saveUi());
  }

  bool get exitBlocked => capturePermission || recordingBusy;

  List<Map<String, String>> operationsFor(String studentId) =>
      skipEvents.where((event) => event['studentId'] == studentId).toList();

  Student? _nextInRun(String id) {
    final index = _runOrder.indexWhere((s) => s.id == id);
    if (index < 0) return null;
    return _runOrder
        .skip(index + 1)
        .where(
          (s) => s.profileComplete && savedCount(s) == 0 && !isSkipped(s.id),
        )
        .firstOrNull;
  }

  Future<void> setSkipped(String studentId, bool skipped) async {
    if (isSkipped(studentId) == skipped) return;
    final prepared = preparedStudent;
    final advance = skipped && capturePermission && prepared?.id == studentId;
    if (skipped && recordingBusy && prepared?.id == studentId) return;
    if (advance) {
      final error = await stopCapture();
      // A start arriving while disable is in flight still owns this student.
      if (error != null || recordingBusy) return;
    }
    if (skipped) {
      skippedStudentIds.add(studentId);
      if (advance ||
          (capturePermission && _runOrder.any((s) => s.id == studentId))) {
        _runSkipped.add(studentId);
      }
    } else {
      skippedStudentIds.remove(studentId);
      _runSkipped.remove(studentId);
      if (capturePermission) {
        final current = _runOrder.indexWhere((s) => s.id == prepared?.id);
        final restored = _runOrder.indexWhere((s) => s.id == studentId);
        if (restored >= 0 && restored < current) {
          final item = _runOrder[restored];
          _runOrder = [..._runOrder.where((s) => s.id != studentId), item];
        }
      }
    }
    skipEvents.add({
      'studentId': studentId,
      'action': skipped ? 'skip' : 'clear',
      'time': DateTime.now().toIso8601String(),
    });
    notifyListeners();
    await _saveUi();
    if (advance) {
      final next = _nextInRun(studentId);
      if (next == null) {
        unawaited(_announceEnd(prepared!));
      } else {
        selectedStudentId = next.id;
        final error = await startCapture(continueRun: true);
        if (error != null) status = error;
      }
    }
  }

  ShotSnapshot get shot {
    final student = selectedStudent;
    if (student == null) {
      return const ShotSnapshot(
        phase: ShotPhase.idle,
        elapsed: 0,
        captureId: null,
      );
    }
    if (_mockRunning && _mockStudentId == student.id && _mockStarted != null) {
      final elapsed = DateTime.now().difference(_mockStarted!).inSeconds;
      return ShotSnapshot(
        phase: ShotPhase.recording,
        elapsed: elapsed,
        captureId: _mockCaptureId,
        drill: true,
      );
    }
    final target = _shotSession;
    if (target != null &&
        target.pendingCommands.contains(devices.currentId) &&
        target.armedStudent?.id == student.id) {
      return const ShotSnapshot(
        phase: ShotPhase.waiting,
        elapsed: 0,
        captureId: null,
      );
    }
    final pending = [
      for (final session in sessions)
        for (final entry in session.captureTimes.entries)
          if (session.captureStudents[entry.key]?.id == student.id &&
              session.capturePhases[entry.key] != 'cancelled')
            (session: session, id: entry.key, time: entry.value),
    ]..sort((a, b) => b.time.compareTo(a.time));
    if (pending.isNotEmpty) {
      final latest = pending.first;
      final elapsed = latest.session.captureDurations[latest.id] != null
          ? latest.session.captureDurations[latest.id]! ~/ 1000
          : latest.session.capturePhases[latest.id] == 'recording'
          ? (_recordingClocks.putIfAbsent(
              latest.id,
              () => Stopwatch()..start(),
            )).elapsed.inSeconds
          : (_recordingClocks[latest.id]?.elapsed.inSeconds ?? 0);
      final phase = switch (latest.session.capturePhases[latest.id]) {
        'prepared' || 'starting' => ShotPhase.waiting,
        'finalizing' => ShotPhase.finalizing,
        'recording' => ShotPhase.recording,
        'uploading' => ShotPhase.uploading,
        'failed' => ShotPhase.failed,
        _ => ShotPhase.leftOnDevice,
      };
      return ShotSnapshot(phase: phase, elapsed: elapsed, captureId: latest.id);
    }
    if (_savedBannerFor == student.id) {
      return ShotSnapshot(
        phase: ShotPhase.saved,
        elapsed:
            sessions
                    .expand((s) => s.completionEvents.values)
                    .where((e) => e['studentId'] == student.id)
                    .lastOrNull?['durationMs']
                is num
            ? ((sessions
                              .expand((s) => s.completionEvents.values)
                              .where((e) => e['studentId'] == student.id)
                              .last['durationMs']
                          as num)
                      .toInt() ~/
                  1000)
            : 10,
        captureId: null,
        drill: _drillSaved,
      );
    }
    return const ShotSnapshot(
      phase: ShotPhase.idle,
      elapsed: 0,
      captureId: null,
    );
  }

  bool get captureBusy {
    if (_mockRunning || capturePermission) return true;
    final id = devices.currentId;
    return id != null &&
        sessions.any(
          (session) =>
              session.pendingCommands.contains(id) ||
              (session.activeCaptureId != null &&
                  session.captureDevices[session.activeCaptureId] == id),
        );
  }

  List<RecordRow> get recordRows =>
      _allRecords().where(_recordVisible).toList();

  List<RecordRow> historyFor(String studentId) => _allRecords()
      .where(
        (row) =>
            row.studentId == studentId &&
            row.studentId.isNotEmpty &&
            (row.record != null ||
                const {
                  'pending_local',
                  'completed_pending',
                  'uploading',
                  'failed',
                }.contains(row.session?.capturePhases[row.captureId])),
      )
      .toList();

  List<RecordRow> _allRecords() {
    final rows = <RecordRow>[];
    for (final session in sessions) {
      for (final record in session.records) {
        final student = record.student;
        rows.add(
          RecordRow(
            captureId: record.captureId,
            deviceId: record.deviceId,
            time: record.time,
            status: record.captureResult == 'short'
                ? '短片需重拍'
                : record.captureResult == 'failed'
                ? '失败留片'
                : record.deviceId == offlineDrillDeviceId
                ? '脱机演练'
                : record.unassigned
                ? '未归属'
                : '已保存电脑',
            school: student?.school ?? session.school,
            grade: student?.grade ?? '',
            klass: student?.klass ?? '',
            studentNo: student?.studentNo ?? '',
            name: student?.name ?? '',
            studentId: student?.id ?? '',
            fileName: record.fileName,
            session: session,
            record: record,
          ),
        );
      }
      for (final entry in session.captureTimes.entries) {
        if (session.records.any((record) => record.captureId == entry.key)) {
          continue;
        }
        final student = session.captureStudents[entry.key];
        final phase = session.capturePhases[entry.key];
        rows.add(
          RecordRow(
            captureId: entry.key,
            deviceId: session.captureDevices[entry.key] ?? '',
            time: entry.value,
            status: switch (phase) {
              'prepared' => '等待按键',
              'starting' => '准备开录',
              'finalizing' => '录像收尾',
              'pending_local' =>
                session.captureResults[entry.key] == 'short' ? '过短需重拍' : '已拍待传',
              'recording' => '录制中',
              'uploading' => '上传中',
              'failed' => '拍摄失败',
              _ => '待同步',
            },
            school: student?.school ?? session.school,
            grade: student?.grade ?? '',
            klass: student?.klass ?? '',
            studentNo: student?.studentNo ?? '',
            name: student?.name ?? '',
            studentId: student?.id ?? '',
            fileName: '',
            session: session,
          ),
        );
      }
    }
    rows.sort((a, b) => b.time.compareTo(a.time));
    return rows;
  }

  bool _recordVisible(RecordRow row) {
    if (schoolFilter != null && row.school != schoolFilter) return false;
    if (gradeFilter != null && row.grade != gradeFilter) return false;
    if (classFilter != null && row.klass != classFilter) return false;
    if (recordStatus != '全部' && row.status != recordStatus) return false;
    final query = recordQuery.trim();
    if (query.isEmpty) return true;
    return row.name.contains(query) || row.studentNo.contains(query);
  }

  Future<void> initialize({int serverPort = 8080}) async {
    try {
      await dataRoot.create(recursive: true);
      devices.addListener(notifyListeners);
      await devices.load(dataRoot);
      students = await _loadStudents();
      await _openSessions();
      await _loadUi();
      _adoptDevicesFromSessions();
      ProtocolLog.directory = Directory(p.join(dataRoot.path, '日志'));
      server = InstrumentServer(
        _activeSession,
        knownSessions: () => sessions,
        devices: devices,
        dataRoot: dataRoot,
        acceptPreparedStart: (deviceId, captureId, gateId, bootId) =>
            _gateValid &&
            deviceId == _gateDeviceId &&
            gateId == _gateId &&
            bootId == _gateBootId,
        onCaptureCompleted: _completeCapture,
        afterCaptureCompleted: _prepareAfterCompletion,
      );
      if (sessions.isEmpty) {
        final opened = await SurveySession.open(
          dataRoot,
          students.isEmpty ? '未选择学校' : students.first.school,
          students,
          DateTime.now(),
        );
        _watch(opened);
        sessions.add(opened);
      }
      _syncDevice();
      try {
        await server!.start(port: serverPort);
      } on SocketException catch (error, stack) {
        await ErrorLog.write(
          'InstrumentServer.start (port 8080)',
          error,
          stack,
        );
        status = '设备服务未启动：请检查 8080 端口';
        notifyListeners();
        return;
      }
      _discoveryRetry?.cancel();
      _discoveryRetry = Timer.periodic(const Duration(seconds: 10), (_) async {
        if ((devices.refreshStarted != null && !devices.refreshSettled) ||
            devices.currentReady ||
            (devices.currentId == null &&
                devices.devices.values.any((device) => device.online))) {
          return;
        }
        try {
          await refreshDevices();
        } catch (error, stack) {
          await ErrorLog.write('AppController.discoveryRetry', error, stack);
        }
      });
      await refreshDevices();
      _gateTimer = Timer.periodic(const Duration(seconds: 2), (_) {
        unawaited(_renewCapturePermission());
      });
      _queryTimer = Timer.periodic(const Duration(seconds: 2), (_) {
        unawaited(_pollQueryDevices());
      });
      unawaited(_pollQueryDevices());
    } catch (error, stack) {
      await ErrorLog.write('AppController.initialize', error, stack);
      status = '启动未完成，请查看错误日志';
    }
    notifyListeners();
  }

  SurveySession _activeSession() {
    final shot = _shotSession;
    if (shot != null) return shot;
    if (sessions.isEmpty) {
      throw StateError('筛查会话尚未就绪');
    }
    return sessions.first;
  }

  Future<List<Student>> _loadStudents() async {
    var loaded = await readMasterRoster(dataRoot);
    if (loaded.isEmpty) {
      final daily = await readDailyRoster(dataRoot, DateTime.now());
      if (daily != null) loaded = [...daily];
      final root = Directory(p.join(dataRoot.path, '筛查'));
      if (await root.exists()) {
        final known = loaded.map((s) => s.schoolNoKey).toSet();
        await for (final entity in root.list()) {
          if (entity is! Directory) continue;
          final file = File(p.join(entity.path, '名单.csv'));
          if (!await file.exists()) continue;
          try {
            for (final student in await readRoster(file)) {
              if (known.add(student.schoolNoKey)) loaded.add(student);
            }
          } on FormatException {
            continue;
          }
        }
      }
    }
    final withIds = ensureStudentIds(loaded);
    final missingId = loaded.any((student) => student.id.isEmpty);
    if (withIds.isNotEmpty &&
        (missingId || !await masterRosterFile(dataRoot).exists())) {
      await saveMasterRoster(dataRoot, withIds);
    }
    return withIds;
  }

  Future<void> _openSessions() async {
    final root = Directory(p.join(dataRoot.path, '筛查'));
    if (!await root.exists()) return;
    final today = DateFormat('yyyyMMdd').format(DateTime.now());
    final folders = await root
        .list()
        .where((entity) => entity is Directory)
        .cast<Directory>()
        .toList();
    folders.sort((a, b) => b.path.compareTo(a.path));
    for (final folder in folders) {
      final name = p.basename(folder.path);
      if (name.length < 9 || name[8] != '_') continue;
      final dayText = name.substring(0, 8);
      late final DateTime day;
      try {
        day = DateTime(
          int.parse(dayText.substring(0, 4)),
          int.parse(dayText.substring(4, 6)),
          int.parse(dayText.substring(6, 8)),
        );
        if (DateFormat('yyyyMMdd').format(day) != dayText) continue;
      } on FormatException {
        continue;
      }
      final rosterFile = File(p.join(folder.path, '名单.csv'));
      List<Student> listed = [];
      if (await rosterFile.exists()) {
        try {
          listed = await readRoster(rosterFile);
        } on FormatException {
          continue;
        }
      } else if (!await File(p.join(folder.path, '记录.csv')).exists() &&
          !await File(p.join(folder.path, '状态.json')).exists()) {
        continue;
      }
      final school = listed.isEmpty ? name.substring(9) : listed.first.school;
      final isToday = dayText == today;
      final opened = await SurveySession.open(
        dataRoot,
        school,
        isToday ? students : listed,
        day,
        writeRoster: isToday,
      );
      _watch(opened);
      sessions.add(opened);
    }
  }

  void _watch(SurveySession session) {
    var seen = session.records.length;
    session.addListener(() {
      for (final entry in session.capturePhases.entries) {
        if (entry.value == 'recording') {
          _recordingClocks.putIfAbsent(entry.key, () => Stopwatch()..start());
        } else if (entry.value == 'finalizing') {
          _recordingClocks[entry.key]?.stop();
        }
      }
      if (session.records.length > seen) {
        final newest = session.records.last;
        if (newest.student?.id != null &&
            newest.student!.id == selectedStudentId) {
          _savedBannerFor = selectedStudentId;
          _drillSaved = newest.deviceId == offlineDrillDeviceId;
          session.devices[devices.currentId]?.holdOnline = false;
        }
      }
      seen = session.records.length;
      notifyListeners();
    });
  }

  void _adoptDevicesFromSessions() {
    if (devices.paired.isNotEmpty) return;
    for (final session in sessions) {
      devices.paired.addAll(session.paired);
      devices.currentId ??= session.currentDeviceId;
    }
    if (devices.currentId == null && devices.paired.isNotEmpty) {
      devices.currentId = devices.paired.first;
    }
  }

  void _syncDevice() {
    final id = devices.currentId;
    for (final session in sessions) {
      session.currentDeviceId = id;
      session.paired
        ..removeWhere((item) => !devices.paired.contains(item))
        ..addAll(devices.paired);
    }
  }

  Future<({String label, String address})> _nic() async {
    final interfaces = await NetworkInterface.list(
      type: InternetAddressType.IPv4,
    );
    bool lan(InternetAddress address) {
      final ip = address.address;
      return !address.isLoopback &&
          !ip.startsWith('169.254.') &&
          !ip.startsWith('198.18.');
    }

    final usable = interfaces.where((item) => item.addresses.any(lan)).toList();
    final preferred = usable
        .where(
          (item) =>
              RegExp('WLAN|Wi-Fi', caseSensitive: false).hasMatch(item.name),
        )
        .toList();
    final chosen = (preferred.isNotEmpty ? preferred : usable).firstOrNull;
    final address = chosen?.addresses.where(lan).firstOrNull?.address;
    return (label: chosen?.name ?? '未找到局域网网卡', address: address ?? '没有可用 IPv4');
  }

  void go(AppPage next) {
    page = next;
    notifyListeners();
  }

  Future<void> refreshDevices() async {
    final nic = await _nic();
    devices
      ..serverPort = DebugBridge.receivingPort(server?.port ?? 0)
      ..beginRefresh(nicLabel: nic.label, nicAddress: nic.address);
    try {
      final transactions = <String, String>{};
      for (final id in devices.paired) {
        final txn = devices.committedPairTransactions[id];
        if (txn != null) transactions[id] = txn;
      }
      final recovered = await recoverPairedOnLan(devices.hostId, transactions);
      for (final entry in recovered.entries) {
        devices.put(entry.key).ip = entry.value;
      }
      if (recovered.isNotEmpty) await devices.save(dataRoot);
      final replies = await broadcastOnLan(httpPort: devices.serverPort);
      for (final reply in replies) {
        devices.noteUdp(reply.deviceId, reply.firmware, reply.from.address);
      }
      if (replies.isEmpty) {
        status = '已在 ${nic.address} 广播，没有仪器回应';
      } else {
        status = '广播发现 ${replies.map((reply) => reply.deviceId).join('、')}';
      }
    } on SocketException catch (error) {
      status = '广播失败：$error';
    }
    devices.finishRefresh();
    notifyListeners();
  }

  Future<void> _pollQueryDevices() async {
    if (_queryBusy || _queryStopped) return;
    _queryBusy = true;
    try {
      final discovered = devices.discovered.map((device) => device.id).toSet();
      final targets = devices.devices.values.where(
        (device) =>
            device.ip.isNotEmpty &&
            (devices.paired.contains(device.id) ||
                discovered.contains(device.id) ||
                devices.pairTransactions.containsKey(device.id) ||
                devices.pendingUnpairEvents.containsKey(device.id)),
      );
      for (final device in targets) {
        if (_queryStopped) return;
        final address = InternetAddress.tryParse(device.ip);
        if (address == null || address.type != InternetAddressType.IPv4) {
          continue;
        }
        final attempts = device.queryActive ? 4 : 1;
        for (var attempt = 0; attempt < attempts; attempt++) {
          final querySentAt = DateTime.now();
          Map<String, dynamic>? reply;
          try {
            reply = await queryDevice(
              device.id,
              address,
              hostId: devices.hostId,
              sequence: ++_querySequence,
            );
          } on SocketException {
            // Existing boards keep reporting through /api/v1/hello.
          }
          if (_queryStopped) return;
          if (reply != null) {
            final oldBoot = device.bootId;
            if (!_connectedUploadDevices.contains(device.id) ||
                (oldBoot.isNotEmpty && oldBoot != reply['boot_id'])) {
              pausedUploadDevices.remove(device.id);
            }
            _connectedUploadDevices.add(device.id);
            final lastSequence =
                (reply['control_sequence'] as num?)?.toInt() ?? 0;
            _controlSequences[device.id] = max(
              _controlSequences[device.id] ?? 0,
              lastSequence,
            );
            devices.noteQueryReply(device.id, reply);
            if (capturePermission &&
                device.id == _gateDeviceId &&
                (oldBoot != device.bootId ||
                    device.pairedHostId != devices.hostId ||
                    (_gateConfirmedAt != null &&
                        !querySentAt.isBefore(_gateConfirmedAt!) &&
                        (!device.gateEnabled || device.gateId != _gateId)))) {
              await stopCapture();
            }
            if (devices.pairTransactions.containsKey(device.id) ||
                (devices.paired.contains(device.id) &&
                    devices.committedPairTransactions.containsKey(device.id) &&
                    device.pairedHostId == devices.hostId &&
                    ((reply['peer_ip'] is String &&
                            reply['peer_ip'] != devices.nicAddress) ||
                        (reply['http_port'] is num &&
                            reply['http_port'] !=
                                DebugBridge.receivingPort(
                                  server?.port ?? 8080,
                                ))))) {
              try {
                await pair(device.id);
              } catch (error, stack) {
                await ErrorLog.write('recover pairing', error, stack);
              }
            }
            if (!devices.paired.contains(device.id) &&
                device.pairedHostId == devices.hostId &&
                devices.pendingUnpairEvents.containsKey(device.id)) {
              final result = await _control(device, 'unpair', {
                'txn_id': devices.pendingUnpairEvents[device.id],
              });
              if (result?['ok'] == true) {
                devices.pendingUnpairEvents.remove(device.id);
                await devices.save(dataRoot);
              }
            }
            // A board re-paired to this host may still carry the revocation
            // event addressed to its previous host.
            final unpairEvent = reply['unpair_event_id'];
            if (unpairEvent is String &&
                unpairEvent.isNotEmpty &&
                device.pairedHostId != devices.hostId) {
              if (devices.paired.contains(device.id)) {
                await _localUnpair(device.id);
              }
              await _control(device, 'event_ack', {'event_id': unpairEvent});
            }
            if (device.pairedHostId == devices.hostId &&
                devices.paired.contains(device.id)) {
              unawaited(_grantPendingUploads(device));
            }
            break;
          }
          if (!device.queryActive) break;
          devices.noteQueryMiss(device.id);
          if (!device.online) _connectedUploadDevices.remove(device.id);
          if (!device.online && device.id == _gateDeviceId) await stopCapture();
        }
      }
    } catch (error, stack) {
      await ErrorLog.write('AppController.queryDevices', error, stack);
    } finally {
      _queryBusy = false;
    }
  }

  Future<void> pair(String id) async {
    final device = devices.put(id);
    final newlyPaired = !devices.paired.contains(id);
    if (!device.supportsCaptureGate) {
      throw StateError('仪器版本不支持新版配对，请更新固件或使用旧版回退工具');
    }
    final txn =
        devices.pairTransactions[id] ??
        devices.committedPairTransactions[id] ??
        _uniqueId('pair');
    final accepted = await _control(device, 'pair_request', {
      'txn_id': txn,
      'http_port': DebugBridge.receivingPort(server?.port ?? 8080),
    });
    if (accepted?['ok'] != true) throw StateError('配对未完成：请长按中键 3 秒打开配对窗口');
    devices.pairTransactions[id] = txn;
    await devices.save(dataRoot);
    final committed = await _control(device, 'pair_commit', {
      'txn_id': txn,
      'http_port': DebugBridge.receivingPort(server?.port ?? 8080),
    });
    if (committed?['ok'] != true) throw StateError('配对最终确认未收到，请重试同一事务');
    await devices.pairAsCurrent(id);
    device.pairedHostId = devices.hostId;
    devices.pairTransactions.remove(id);
    devices.committedPairTransactions[id] = txn;
    devices.pendingUnpairEvents.remove(id);
    _syncDevice();
    for (final session in sessions) {
      await session.setPaired(id, true);
    }
    await devices.save(dataRoot);
    if (newlyPaired) {
      pausedUploadDevices.remove(id);
      page = AppPage.capture;
    }
    notifyListeners();
  }

  Future<void> makeCurrent(String id) async {
    await devices.makeCurrent(id);
    for (final session in sessions) {
      session.pendingCommands.removeWhere((deviceId) => deviceId != id);
    }
    _syncDevice();
    await devices.save(dataRoot);
    notifyListeners();
  }

  Future<void> unpair(String id) async {
    if (id == _gateDeviceId) await stopCapture();
    final device = devices.put(id);
    await _localUnpair(id);
    if (device.supportsCaptureGate) {
      await _control(device, 'unpair', {
        'txn_id': devices.pendingUnpairEvents[id]!,
      });
    }
  }

  Future<void> _localUnpair(String id) async {
    if (id == _gateDeviceId) await stopCapture();
    await devices.unpair(id);
    for (final session in sessions) {
      await session.setPaired(id, false);
    }
    _syncDevice();
    await devices.save(dataRoot);
    notifyListeners();
  }

  Future<void> setDeviceVolume(String id, int volume) async {
    await _deviceAudio(id, volume, 'volume_set');
    devices.setTargetVolume(id, volume);
    devices.put(id).volume = volume;
    await devices.save(dataRoot);
    notifyListeners();
  }

  Future<void> testDeviceVolume(String id, int volume) =>
      _deviceAudio(id, volume, 'volume_test');

  Future<void> _deviceAudio(String id, int volume, String op) async {
    final device = devices.put(id);
    if (volume < 0 || volume > 30) throw ArgumentError('音量必须在 0 到 30 之间');
    if (!devices.paired.contains(id) || !device.online) {
      throw StateError('请先连接仪器');
    }
    if (!device.capabilities.contains('volume_control')) {
      throw StateError('仪器尚不支持远程音量控制，请更新固件');
    }
    if (capturePermission || recordingBusy || device.audioBusy) {
      throw StateError('请先停止拍摄许可，并等待录像收尾和提示音结束');
    }
    final operation = _uniqueId('audio');
    try {
      final reply = await _control(device, op, {
        'volume': volume,
        'operation_id': operation,
      });
      if (reply?['ok'] != true) throw StateError('仪器未接受音量操作，请稍后重试');
      final deadline = DateTime.now().add(const Duration(seconds: 15));
      while (DateTime.now().isBefore(deadline)) {
        final state = await _control(device, 'hello_query', {});
        if (state != null) devices.noteQueryReply(id, state);
        if (state?['audio_operation_id'] == operation &&
            state?['audio_busy'] == false) {
          if (state?['audio_operation_result'] != 0) {
            throw StateError('仪器音量操作失败，请查看错误日志');
          }
          if (op == 'volume_set' && state?['volume'] != volume) {
            throw StateError('仪器音量确认不一致');
          }
          return;
        }
        await Future<void>.delayed(const Duration(milliseconds: 150));
      }
      throw StateError('仪器音量操作确认超时，未重复播放，请核对设备');
    } catch (error, stack) {
      await ErrorLog.write(op, error, stack);
      rethrow;
    }
  }

  Future<ImportPreview> inspectImport(File file) =>
      previewImport(file, students);

  Future<void> commitPreview(ImportPreview preview) async {
    final batch = DateTime.now();
    students = commitImport(students, preview, batch);
    await saveMasterRoster(dataRoot, students);
    await _pushRosterToToday();
    notifyListeners();
  }

  Future<void> addOne(Student student) async {
    final stamped = student.importedAt == null
        ? student.copyWith(importedAt: DateTime.now())
        : student;
    students = [...students, stamped];
    await saveMasterRoster(dataRoot, students);
    await _pushRosterToToday();
    notifyListeners();
  }

  Future<void> updateOne(Student next) async {
    students = [
      for (final student in students)
        if (student.id == next.id) next else student,
    ];
    await saveMasterRoster(dataRoot, students);
    await _pushRosterToToday();
    notifyListeners();
  }

  Future<void> deleteOne(String id) async {
    students = students.where((s) => s.id != id).toList();
    await saveMasterRoster(dataRoot, students);
    await _pushRosterToToday();
    if (selectedStudentId == id) selectedStudentId = null;
    notifyListeners();
  }

  Future<int> deleteSchoolRoster(String school) async {
    final remaining = students.where((s) => s.school != school).toList();
    final removed = students.length - remaining.length;
    if (removed == 0) return 0;
    await saveMasterRoster(dataRoot, remaining);
    students = remaining;
    await _pushRosterToToday();
    if (schoolFilter == school) {
      schoolFilter = null;
      gradeFilter = null;
      classFilter = null;
    }
    if (students.every((s) => s.id != selectedStudentId)) {
      _selectInitialStudent();
    }
    notifyListeners();
    await _saveUi();
    return removed;
  }

  Future<void> _pushRosterToToday() async {
    final today = DateFormat('yyyyMMdd').format(DateTime.now());
    for (final session in sessions) {
      final folder = p.basename(session.directory.path);
      if (!folder.startsWith(today)) continue;
      await session.replaceStudents(students);
    }
  }

  void setScope({
    String? school,
    String? grade,
    String? klass,
    bool clearSchool = false,
    bool clearGrade = false,
    bool clearClass = false,
  }) {
    if (clearSchool) {
      schoolFilter = null;
      gradeFilter = null;
      classFilter = null;
    } else {
      schoolFilter = school ?? schoolFilter;
    }
    if (clearGrade) gradeFilter = null;
    if (grade != null) gradeFilter = grade;
    if (clearClass || clearGrade) classFilter = null;
    if (klass != null) classFilter = klass;
    final visible = classStudents;
    if (!captureBusy && visible.every((s) => s.id != selectedStudentId)) {
      selectedStudentId =
          visible.where((s) => s.profileComplete).firstOrNull?.id ??
          visible.firstOrNull?.id;
    }
    notifyListeners();
    unawaited(_saveUi());
  }

  void setSort(RosterSort next) {
    sort = next;
    notifyListeners();
    unawaited(_saveUi());
  }

  void setGenderOrder(GenderOrder next) {
    genderOrder = next;
    notifyListeners();
    unawaited(_saveUi());
  }

  Future<void> setAnnounceNextName(bool value) async {
    announceNextName = value;
    if (!value) await _speaker.stop();
    notifyListeners();
    await _saveUi();
  }

  Future<String?> speakCurrentName() async {
    final student = selectedStudent;
    if (student == null) return '请先选择一位学生';
    final name = student.name.trim();
    if (name.isEmpty) return '当前学生没有姓名';
    try {
      await _speaker.speak('下一位，$name');
    } catch (error, stack) {
      await ErrorLog.write('NameSpeaker.speak', error, stack);
      return '语音播报失败：$error';
    }
    return null;
  }

  Future<void> _announce(Student student, {String? text}) async {
    if (!announceNextName) return;
    final name = student.name.trim();
    if (name.isEmpty) return;
    try {
      await _speaker.speak(text ?? '下一位，$name');
    } catch (error, stack) {
      await ErrorLog.write('NameSpeaker.speak', error, stack);
    }
  }

  Future<void> _announceEnd(Student student) => _announce(
    student,
    text:
        '完成${student.grade}${_spokenClass(student)}${_runSuccess.length}人的拍摄，跳过${_runSkipped.length}人',
  );

  String _spokenClass(Student student) =>
      student.klass.endsWith('班') ? student.klass : '${student.klass}班';

  void setMode(CaptureMode next) {
    captureMode = next;
    notifyListeners();
    unawaited(_saveUi());
  }

  void selectStudent(String id) {
    selectedStudentId = id;
    _savedBannerFor = null;
    _drillSaved = false;
    final student = selectedStudent;
    if (student != null) {
      schoolFilter = student.school;
      gradeFilter = student.grade;
      classFilter = student.klass.isEmpty ? classFilter : student.klass;
    }
    notifyListeners();
    unawaited(_saveUi());
  }

  List<Student> searchStudents(String query) {
    final text = query.trim();
    if (text.isEmpty) return [];
    return students
        .where(
          (s) =>
              _captureVisible(s) &&
              (s.name.contains(text) || s.studentNo.contains(text)),
        )
        .toList();
  }

  Future<String?> startCapture({bool continueRun = false}) async {
    final student = selectedStudent;
    if (student == null) return '请先选择一位学生';
    if (!continueRun && !_captureVisible(student)) return '请选择当前性别筛选中的学生';
    if (!student.profileComplete) return '学生资料缺项，请到名单页修改';
    if (recordingBusy) {
      return '这一台设备正在拍摄';
    }
    _startingCapture = true;
    notifyListeners();
    try {
      if (capturePermission) {
        final stopped = await stopCapture();
        if (stopped != null) return stopped;
        if (sessions.any(
              (s) =>
                  s.activeCaptureId != null &&
                  const {
                    'starting',
                    'recording',
                    'finalizing',
                  }.contains(s.capturePhases[s.activeCaptureId]),
            ) ||
            const {
              'starting',
              'recording',
              'finalizing',
            }.contains(devices.current?.capturePhase)) {
          return '原轮次已经开录，请等待当前视频收尾后再切换';
        }
      }
      final currentId = devices.currentId;
      if (currentId == null ||
          !devices.paired.contains(currentId) ||
          !devices.currentReady) {
        if (devices.current?.supportsCaptureGate == true) {
          return '仪器通信离线或尚未就绪，请恢复通信后重新开始';
        }
        return _startOfflineDrill(student);
      }
      final device = devices.current!;
      if (!device.supportsCaptureGate) return '仪器版本不支持按键多轮拍摄，请更新固件或使用旧版回退工具';
      if (device.pairedHostId != devices.hostId) return '仪器尚未完成与本电脑的新协议配对';
      final target = await _ensureToday(student.school);
      if (!continueRun) {
        _runMode = captureMode;
        _runOrder = List<Student>.of(captureStudents);
        _runSuccess.clear();
        _runSkipped.clear();
      }
      final gate = _uniqueId('gate');
      final id = _uniqueId('$currentId-v3');
      await target.prepareCapture(currentId, id, gate, student);
      _shotSession = target;
      _gateId = gate;
      _gateDeviceId = currentId;
      _gateBootId = device.bootId;
      capturePermission = true;
      _gateConfirmedAt = null;
      _leaseAge.stop();
      _savedBannerFor = null;
      notifyListeners();
      try {
        final enabled = await _control(device, 'capture_enable', {
          'gate_id': gate,
          'ttl_ms': 6000,
        });
        if (_gateId != gate || !capturePermission) return '拍摄许可已停止';
        if (enabled?['ok'] != true) {
          await stopCapture();
          return '仪器未确认拍摄许可，请重新开始';
        }
        _gateConfirmedAt = DateTime.now();
        _leaseAge
          ..reset()
          ..start();
        final prepared = await _control(device, 'capture_prepare', {
          'gate_id': gate,
          'capture_id': id,
        });
        if (_gateId != gate || !capturePermission) return '拍摄许可已停止';
        if (prepared?['ok'] != true) {
          await stopCapture();
          return '仪器未确认本轮准备，请重新开始';
        }
        _preparedControlIds.add(id);
        unawaited(
          _announce(
            student,
            text: continueRun
                ? null
                : (_runMode == CaptureMode.sequence
                      ? '${student.grade}${_spokenClass(student)}，第一位，${student.name}'
                      : student.name),
          ),
        );
        return null;
      } catch (_) {
        if (_gateId == gate) await stopCapture();
        rethrow;
      }
    } finally {
      _startingCapture = false;
      notifyListeners();
    }
  }

  /// Closing the gate never interrupts a recording already in progress.
  Future<String?> stopCapture() async {
    final deviceId = _gateDeviceId;
    final gate = _gateId;
    capturePermission = false;
    _gateConfirmedAt = null;
    _leaseAge.stop();
    notifyListeners();
    if (deviceId == null || gate == null) return null;
    final device = devices.devices[deviceId];
    if (device != null) {
      final reply = await _control(device, 'capture_disable', {
        'gate_id': gate,
      }, priority: true);
      if (reply?['ok'] != true && device.online) return '仪器未确认停止，请等待许可失效后重试';
      if (reply?['phase'] is String) {
        device.capturePhase = reply!['phase'] as String;
      }
    }
    for (final session in sessions) {
      await session.cancelPrepared(deviceId, gateId: gate);
    }
    return null;
  }

  Future<Map<String, dynamic>?> _control(
    DeviceInfo device,
    String op,
    Map<String, Object?> fields, {
    bool priority = false,
  }) {
    final completer = Completer<Map<String, dynamic>?>();
    Future<void> run() async {
      try {
        if (_queryStopped ||
            device.bootId.isEmpty ||
            device.ip.isEmpty ||
            (op.startsWith('capture_') &&
                op != 'capture_disable' &&
                (!capturePermission || fields['gate_id'] != _gateId))) {
          completer.complete(null);
          return;
        }
        final address = InternetAddress.tryParse(device.ip);
        if (address == null) {
          completer.complete(null);
          return;
        }
        final sequence =
            max(_controlSequences[device.id] ?? 0, device.controlSequence) + 1;
        _controlSequences[device.id] = sequence;
        completer.complete(
          await queryDevice(
            device.id,
            address,
            hostId: devices.hostId,
            sequence: sequence,
            op: op,
            bootId: device.bootId,
            fields: fields,
          ),
        );
      } catch (error, stack) {
        completer.completeError(error, stack);
      }
    }

    if (priority) {
      _controls.insert(0, (run: run, priority: true));
    } else {
      _controls.add((run: run, priority: false));
    }
    unawaited(_runControls());
    return completer.future;
  }

  Future<void> _runControls() async {
    if (_controlBusy) return;
    _controlBusy = true;
    try {
      while (_controls.isNotEmpty) {
        await _controls.removeAt(0).run();
      }
    } finally {
      _controlBusy = false;
    }
  }

  Future<void> _renewCapturePermission() async {
    if (_renewBusy || !capturePermission || _queryStopped) return;
    if (_gateConfirmedAt == null) return;
    if (!_gateValid) {
      await stopCapture();
      return;
    }
    _renewBusy = true;
    try {
      final device = devices.devices[_gateDeviceId];
      if (device == null || !device.online || device.bootId != _gateBootId) {
        await stopCapture();
        return;
      }
      final renewingGate = _gateId;
      final reply = await _control(device, 'capture_renew', {
        'gate_id': renewingGate,
        'ttl_ms': 6000,
      });
      if (_gateId != renewingGate) return;
      if (reply?['ok'] == true && capturePermission) {
        _gateConfirmedAt = DateTime.now();
        _leaseAge
          ..reset()
          ..start();
      } else if (reply != null || !_gateValid) {
        await stopCapture();
      }
    } catch (error, stack) {
      await ErrorLog.write('capture renew', error, stack);
      if (!_gateValid) await stopCapture();
    } finally {
      _renewBusy = false;
    }
  }

  Future<Map<String, dynamic>?> _completeCapture(
    SurveySession session,
    Map<String, dynamic> body,
  ) async {
    final deviceId = body['device_id'] as String;
    final captureId = body['capture_id'] as String;
    final eventId = body['event_id'] as String;
    final existing = session.completionEvents[eventId];
    if (body['stop_reason'] == 'unpaired' && deviceId == _gateDeviceId) {
      await stopCapture();
    }
    Student? next;
    String? nextId;
    if (existing == null &&
        _gateValid &&
        body['gate_id'] == _gateId &&
        deviceId == _gateDeviceId) {
      final original = session.captureStudents[captureId];
      if (original == null) return null;
      next = original;
      if (body['result'] == 'success' &&
          (_runMode ?? captureMode) == CaptureMode.sequence) {
        final ordered = _runMode == null ? captureStudents : _runOrder;
        final start = ordered.indexWhere((s) => s.id == original.id);
        next = start < 0
            ? null
            : ordered
                  .skip(start + 1)
                  .where(
                    (s) =>
                        s.profileComplete &&
                        savedCount(s) == 0 &&
                        !isSkipped(s.id),
                  )
                  .firstOrNull;
      }
      if (next != null) nextId = _uniqueId('$deviceId-v3');
    }
    final receipt = await session.completeCapture(
      deviceId: deviceId,
      captureId: captureId,
      eventId: eventId,
      result: body['result'] as String,
      durationMs: (body['duration_ms'] as num).toInt(),
      gateId: body['gate_id'] as String,
      stopReason: body['stop_reason'] as String,
      startedAt: (body['started_at_ms'] as num) <= 0
          ? null
          : DateTime.fromMillisecondsSinceEpoch(
              (body['started_at_ms'] as num).toInt(),
              isUtc: true,
            ),
      endedAt: DateTime.fromMillisecondsSinceEpoch(
        (body['ended_at_ms'] as num).toInt(),
        isUtc: true,
      ),
      nextStudent: next,
      nextCaptureId: nextId,
    );
    if (receipt == null) return null;
    _recordingClocks.remove(captureId)?.stop();
    if (body['gate_id'] == _gateId && receipt['result'] == 'success') {
      _runSuccess.add(receipt['studentId'] as String);
    }
    if (!_appliedCompletionEvents.contains(eventId)) {
      final before = selectedStudentId;
      if (receipt['nextStudentId'] is String) {
        selectedStudentId = receipt['nextStudentId'] as String;
        final nextStudent = selectedStudent;
        if (nextStudent != null) {
          schoolFilter = nextStudent.school;
          gradeFilter = nextStudent.grade;
          classFilter = nextStudent.klass;
        }
      }
      _appliedCompletionEvents.add(eventId);
      try {
        await _saveUi();
      } catch (_) {
        selectedStudentId = before;
        _appliedCompletionEvents.remove(eventId);
        rethrow;
      }
    }
    notifyListeners();
    return {
      'ok': true,
      'received': true,
      'event_id': eventId,
      'capture_id': captureId,
    };
  }

  Future<void> _prepareAfterCompletion(
    SurveySession session,
    Map<String, dynamic> body,
  ) async {
    final receipt = session.completionEvents[body['event_id']];
    if (receipt == null ||
        !_gateValid ||
        body['gate_id'] != _gateId ||
        _queryStopped) {
      return;
    }
    final nextId = receipt['nextCaptureId'];
    if (nextId is! String) {
      final original = session.captureStudents[body['capture_id']];
      await stopCapture();
      if (original != null &&
          (_runMode ?? captureMode) == CaptureMode.sequence) {
        unawaited(_announceEnd(original));
      }
      return;
    }
    if (session.capturePhases[nextId] != 'prepared' ||
        !_preparedControlIds.add(nextId)) {
      return;
    }
    final device = devices.devices[body['device_id']];
    if (device == null) return;
    try {
      final reply = await _control(device, 'capture_prepare', {
        'gate_id': _gateId,
        'capture_id': nextId,
      });
      if (reply?['ok'] != true) {
        await stopCapture();
        return;
      }
      final student = session.captureStudents[nextId];
      if (student != null && receipt['result'] != 'success') {
        unawaited(_announce(student, text: '${student.name}，请重新拍摄'));
      } else if (student != null &&
          (_runMode ?? captureMode) == CaptureMode.sequence) {
        unawaited(_announce(student));
      }
    } catch (error, stack) {
      await ErrorLog.write('prepare next', error, stack);
      await stopCapture();
    }
  }

  Future<void> _grantPendingUploads(DeviceInfo device) async {
    if (_transferBusy ||
        !device.supportsCaptureGate ||
        _queryStopped ||
        uploadsPaused(device.id) ||
        device.uploadingCaptureId.isNotEmpty ||
        DateTime.now().isBefore(_uploadRetryAt[device.id] ?? DateTime(1970))) {
      return;
    }
    _transferBusy = true;
    try {
      var offset = 0;
      do {
        final reply = await _control(device, 'pending_query', {
          'offset': offset,
          'limit': 8,
        });
        if (reply?['ok'] != true || reply?['items'] is! List) return;
        for (final raw in reply!['items'] as List) {
          if (raw is! Map) continue;
          final id = raw['capture_id'];
          final size = raw['size_bytes'];
          final hash = raw['sha256'];
          if (id is! String ||
              size is! num ||
              size <= 0 ||
              hash is! String ||
              !RegExp(r'^[a-fA-F0-9]{64}$').hasMatch(hash)) {
            continue;
          }
          var session = sessions
              .where(
                (s) =>
                    s.captureDevices[id] == device.id ||
                    s.records.any(
                      (r) => r.captureId == id && r.deviceId == device.id,
                    ),
              )
              .firstOrNull;
          session ??= await _ensureToday('未归属');
          if (session.captureGates.containsKey(id) &&
              !session.captureResults.containsKey(id)) {
            continue;
          }
          await session.registerPendingFile(device.id, id, raw);
          if (uploadsPaused(device.id)) return;
          final grant = _uniqueId('grant');
          server?.grantUpload(
            device.id,
            id,
            grant,
            size.toInt(),
            hash.toLowerCase(),
            const Duration(seconds: 30),
          );
          final accepted = await _control(device, 'upload_grant', {
            'capture_id': id,
            'grant_id': grant,
            'ttl_ms': 30000,
            'size_bytes': size.toInt(),
            'sha256': hash,
          });
          if (accepted?['ok'] != true) {
            server?.revokeUpload(id, grant);
          }
          _uploadRetryAt[device.id] = DateTime.now().add(
            const Duration(seconds: 5),
          );
          // One file per cycle keeps renewals and stop commands responsive.
          return;
        }
        final nextOffset = (reply['next_offset'] as num?)?.toInt() ?? -1;
        if (nextOffset <= offset) return;
        offset = nextOffset;
      } while (!_queryStopped);
    } catch (error, stack) {
      await ErrorLog.write('upload grants', error, stack);
    } finally {
      _transferBusy = false;
    }
  }

  Future<SurveySession> _ensureToday(String school) async {
    final day = DateTime.now();
    final folder = p.join(
      dataRoot.path,
      '筛查',
      '${DateFormat('yyyyMMdd').format(day)}_${safePart(school)}',
    );
    final existing = sessions
        .where((session) => session.directory.path == folder)
        .firstOrNull;
    if (existing != null) {
      existing.currentDeviceId = devices.currentId;
      existing.paired.addAll(devices.paired);
      return existing;
    }
    final opened = await SurveySession.open(dataRoot, school, students, day);
    opened.currentDeviceId = devices.currentId;
    opened.paired.addAll(devices.paired);
    _watch(opened);
    sessions.add(opened);
    return opened;
  }

  Future<String?> _startOfflineDrill(Student student) {
    _mockRunning = true;
    _mockStarted = DateTime.now();
    _mockStudentId = student.id;
    _mockStudentSnapshot = student;
    _mockCaptureId = 'MOCK_${_mockStarted!.millisecondsSinceEpoch}';
    _savedBannerFor = null;
    _drillSaved = false;
    final completer = Completer<void>();
    _drillCompleter = completer;
    final step = offlineDrillLength < const Duration(seconds: 1)
        ? const Duration(milliseconds: 15)
        : const Duration(seconds: 1);
    _mockTimer?.cancel();
    _mockTimer = Timer.periodic(step, (_) => _onMockTick());
    notifyListeners();
    return Future.value();
  }

  void _onMockTick() {
    final started = _mockStarted;
    if (!_mockRunning || started == null) return;
    if (DateTime.now().difference(started) >= offlineDrillLength) {
      unawaited(_finishOfflineDrill());
      return;
    }
    notifyListeners();
  }

  Future<void> _finishOfflineDrill() async {
    if (!_mockRunning) return;
    _mockRunning = false;
    _mockTimer?.cancel();
    _mockTimer = null;
    final student = _mockStudentSnapshot;
    final captureId = _mockCaptureId;
    final started = _mockStarted ?? DateTime.now();
    _mockStudentId = null;
    _mockStudentSnapshot = null;
    _mockStarted = null;
    _mockCaptureId = null;
    final completer = _drillCompleter;
    try {
      if (student != null && captureId != null) {
        final target = await _ensureToday(student.school);
        await target.appendOfflineDrill(
          captureId: captureId,
          student: student,
          time: started,
        );
      }
    } catch (error, stack) {
      await ErrorLog.write('AppController.offlineDrill', error, stack);
    } finally {
      notifyListeners();
      if (completer != null && !completer.isCompleted) completer.complete();
    }
  }

  Future<void> goNext() async {
    final current = selectedStudent;
    _savedBannerFor = null;
    _drillSaved = false;
    if (current == null) return;
    final ordered = classStudents;
    final start = ordered.indexWhere((s) => s.id == current.id);
    for (var i = start + 1; i < ordered.length; i++) {
      final candidate = ordered[i];
      if (candidate.profileComplete &&
          savedCount(candidate) == 0 &&
          !isSkipped(candidate.id)) {
        selectedStudentId = candidate.id;
        notifyListeners();
        await _saveUi();
        await _announce(candidate);
        return;
      }
    }
    notifyListeners();
    await _saveUi();
  }

  Future<String?> markPendingAndNext() async {
    final target = _shotSession;
    final student = selectedStudent;
    if (target == null || student == null) return '没有正在进行的拍摄';
    final captureId =
        shot.captureId ??
        target.captureTimes.entries
            .where(
              (entry) => target.captureStudents[entry.key]?.id == student.id,
            )
            .map((entry) => entry.key)
            .firstOrNull;
    if (captureId == null) return '还没有可标记的拍摄';
    await target.markPendingSync(captureId);
    target.devices[devices.currentId]?.holdOnline = false;
    await goNext();
    return null;
  }

  Future<void> assignRecord(RecordRow row, Student student) async {
    final record = row.record;
    final session = row.session;
    if (record == null || session == null) return;
    await session.assign(record, student);
  }

  void setRecordQuery(String value) {
    recordQuery = value;
    notifyListeners();
  }

  void setRecordStatus(String value) {
    recordStatus = value;
    notifyListeners();
  }

  SchoolExportPreview exportPreview(String school) =>
      previewSchoolExport(students, school, sort, genderOrder);

  bool get orderBlocked =>
      schoolFilter != null &&
      orderWarnings(studentsOf(schoolFilter)).isNotEmpty;

  String? get numericWarning =>
      classHasNonNumericStudentNo(classStudents) ? '含非纯数字学号，按文本排序。' : null;

  Future<void> _loadUi() async {
    final file = File(p.join(dataRoot.path, '界面.json'));
    await SurveySession.recoverAtomicFile(file);
    if (!await file.exists()) {
      _selectInitialStudent();
      return;
    }
    try {
      final state =
          jsonDecode(await file.readAsString()) as Map<String, dynamic>;
      schoolFilter = state['school'] as String?;
      gradeFilter = state['grade'] as String?;
      classFilter = state['klass'] as String?;
      selectedStudentId = state['studentId'] as String?;
      captureMode = state['mode'] == 'single'
          ? CaptureMode.single
          : CaptureMode.sequence;
      captureGender =
          CaptureGender.values
              .where((g) => g.name == state['captureGender'])
              .firstOrNull ??
          CaptureGender.all;
      announceNextName = state['announceNextName'] != false;
      _appliedCompletionEvents
        ..clear()
        ..addAll(
          (state['appliedCompletionEvents'] as List? ?? []).cast<String>(),
        );
      skippedStudentIds
        ..clear()
        ..addAll((state['skippedStudentIds'] as List? ?? []).cast<String>());
      skipEvents
        ..clear()
        ..addAll(
          (state['skipEvents'] as List? ?? []).map(
            (item) => (item as Map).cast<String, String>(),
          ),
        );
      sort =
          RosterSort.values
              .where((item) => item.name == state['sort'])
              .firstOrNull ??
          RosterSort.studentNo;
      genderOrder =
          GenderOrder.values
              .where((item) => item.name == state['genderOrder'])
              .firstOrNull ??
          GenderOrder.none;
    } on FormatException {
      _selectInitialStudent();
    }
    if (selectedStudent == null) _selectInitialStudent();
  }

  void _selectInitialStudent() {
    final pending = classStudents
        .where(
          (s) => s.profileComplete && savedCount(s) == 0 && !isSkipped(s.id),
        )
        .firstOrNull;
    selectedStudentId = pending?.id ?? classStudents.firstOrNull?.id;
  }

  Future<void> _saveUi() async {
    final file = File(p.join(dataRoot.path, '界面.json'));
    await file.parent.create(recursive: true);
    await SurveySession.writeAtomicFile(
      file,
      jsonEncode({
        'school': schoolFilter,
        'grade': gradeFilter,
        'klass': classFilter,
        'studentId': selectedStudentId,
        'mode': captureMode == CaptureMode.single ? 'single' : 'sequence',
        'captureGender': captureGender.name,
        'announceNextName': announceNextName,
        'sort': sort.name,
        'genderOrder': genderOrder.name,
        'appliedCompletionEvents': _appliedCompletionEvents.toList(),
        'skippedStudentIds': skippedStudentIds.toList(),
        'skipEvents': skipEvents,
      }),
    );
  }

  @visibleForTesting
  Future<void> loadUiForTest() => _loadUi();

  Future<void> shutdown() => _shutdown ??= _shutdownResources();

  Future<void> _shutdownResources() async {
    _queryStopped = true;
    _gateTimer?.cancel();
    _queryTimer?.cancel();
    _discoveryRetry?.cancel();
    await Future.wait([_speaker.stop(), if (server != null) server!.stop()]);
  }

  @override
  void notifyListeners() {
    if (!_disposed) super.notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    capturePermission = false;
    _gateTimer?.cancel();
    _queryStopped = true;
    _mockTimer?.cancel();
    _mockRunning = false;
    final completer = _drillCompleter;
    if (completer != null && !completer.isCompleted) completer.complete();
    _discoveryRetry?.cancel();
    _queryTimer?.cancel();
    unawaited(
      shutdown().catchError(
        (Object error, StackTrace stack) =>
            ErrorLog.write('shutdown', error, stack),
      ),
    );
    super.dispose();
  }
}
