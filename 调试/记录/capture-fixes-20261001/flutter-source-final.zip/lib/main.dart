import 'dart:async';
import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:path/path.dart' as p;

import 'app/app_controller.dart';
import 'app/error_log.dart';
import 'ui/app_theme.dart';
import 'ui/pages/capture_page.dart';
import 'ui/pages/device_page.dart';
import 'ui/pages/records_page.dart';
import 'ui/pages/roster_page.dart';

void main() {
  runZonedGuarded(
    () {
      WidgetsFlutterBinding.ensureInitialized();
      FlutterError.onError = (details) {
        FlutterError.presentError(details);
        unawaited(
          ErrorLog.write(
            'Flutter',
            details.exception,
            details.stack ?? StackTrace.current,
          ),
        );
      };
      ui.PlatformDispatcher.instance.onError = (error, stack) {
        unawaited(ErrorLog.write('Platform', error, stack));
        return true;
      };
      runApp(const ScoliosisApp());
    },
    (error, stack) {
      unawaited(ErrorLog.write('Uncaught', error, stack));
    },
  );
}

class ScoliosisApp extends StatelessWidget {
  const ScoliosisApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '脊柱侧弯筛查',
      debugShowCheckedModeBanner: false,
      locale: const Locale('zh', 'CN'),
      supportedLocales: const [Locale('zh', 'CN')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ],
      theme: buildTheme(),
      home: HomeShell(
        dataRoot: Directory(p.join(Directory.current.path, 'data')),
      ),
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key, required this.dataRoot});

  final Directory dataRoot;

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  late final AppController controller;
  Timer? ticker;
  static const window = MethodChannel('scoliosis/window');
  bool _closing = false;

  @override
  void initState() {
    super.initState();
    controller = AppController(widget.dataRoot)..addListener(_rebuild);
    window.setMethodCallHandler((call) async {
      if (call.method == 'requestClose') await _requestClose();
    });
    ticker = Timer.periodic(const Duration(seconds: 1), (_) => _rebuild());
    unawaited(controller.initialize());
  }

  Future<void> _requestClose() async {
    if (_closing || !mounted) return;
    _closing = true;
    try {
      if (controller.exitBlocked) {
        await showDialog<void>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('请先停止拍摄'),
            content: const Text('停止拍摄许可后，松开左右键并等待当前视频收尾完成，再关闭应用。'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('知道了'),
              ),
            ],
          ),
        );
        return;
      }
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('确认关闭应用？'),
          content: const Text('尚未传完的视频会保留在仪器，下次连接继续上传。'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('取消'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('确认关闭'),
            ),
          ],
        ),
      );
      if (confirmed != true || controller.exitBlocked) return;
      ticker?.cancel();
      try {
        await controller.shutdown().timeout(const Duration(seconds: 5));
      } catch (error, stack) {
        await ErrorLog.write('close', error, stack);
      }
      await window.invokeMethod<void>('approveClose');
    } finally {
      _closing = false;
    }
  }

  void _rebuild() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    window.setMethodCallHandler(null);
    ticker?.cancel();
    controller.removeListener(_rebuild);
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final page = switch (controller.page) {
      AppPage.device => DevicePage(controller: controller),
      AppPage.roster => RosterPage(controller: controller),
      AppPage.capture => CapturePage(controller: controller),
      AppPage.records => RecordsPage(controller: controller),
    };
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Row(
        children: [
          _Sidebar(controller: controller),
          Expanded(
            child: ColoredBox(color: AppColors.background, child: page),
          ),
        ],
      ),
    );
  }
}

class _Sidebar extends StatelessWidget {
  const _Sidebar({required this.controller});

  final AppController controller;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 220,
      decoration: const BoxDecoration(
        color: AppColors.sidebar,
        border: Border(right: BorderSide(color: AppColors.line, width: 1)),
      ),
      padding: const EdgeInsets.fromLTRB(0, 32, 0, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  '脊柱筛查',
                  style: TextStyle(
                    color: AppColors.text,
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                    letterSpacing: -0.3,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  controller.sidebarStatus,
                  style: const TextStyle(
                    color: AppColors.muted,
                    fontSize: 12,
                    height: 1.4,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),
          _NavItem(
            label: '设备',
            icon: Icons.sensors_outlined,
            selectedIcon: Icons.sensors,
            selected: controller.page == AppPage.device,
            onTap: () => controller.go(AppPage.device),
          ),
          _NavItem(
            label: '名单',
            icon: Icons.groups_outlined,
            selectedIcon: Icons.groups,
            selected: controller.page == AppPage.roster,
            onTap: () => controller.go(AppPage.roster),
          ),
          _NavItem(
            label: '拍摄',
            icon: Icons.photo_camera_outlined,
            selectedIcon: Icons.photo_camera,
            selected: controller.page == AppPage.capture,
            onTap: () => controller.go(AppPage.capture),
          ),
          _NavItem(
            label: '记录',
            icon: Icons.folder_outlined,
            selectedIcon: Icons.folder,
            selected: controller.page == AppPage.records,
            onTap: () => controller.go(AppPage.records),
          ),
          const Spacer(),
          SwitchListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 16),
            title: const Text('自动播报下一位姓名', style: TextStyle(fontSize: 12)),
            value: controller.announceNextName,
            onChanged: (value) =>
                unawaited(controller.setAnnounceNextName(value)),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 0),
            child: Text(
              'v0.0.1',
              style: TextStyle(color: AppColors.muted, fontSize: 11),
            ),
          ),
        ],
      ),
    );
  }
}

class _NavItem extends StatelessWidget {
  const _NavItem({
    required this.label,
    required this.icon,
    required this.selectedIcon,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final IconData selectedIcon;
  final bool selected;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 1, 12, 1),
      child: Material(
        color: selected ? AppColors.surface2 : Colors.transparent,
        borderRadius: BorderRadius.circular(10),
        child: InkWell(
          borderRadius: BorderRadius.circular(10),
          onTap: onTap,
          splashColor: AppColors.primary.withValues(alpha: 0.08),
          highlightColor: AppColors.primary.withValues(alpha: 0.05),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Row(
              children: [
                Icon(
                  selected ? selectedIcon : icon,
                  color: onTap == null
                      ? AppColors.hint
                      : selected
                      ? AppColors.primary
                      : AppColors.muted,
                  size: 20,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    label,
                    style: TextStyle(
                      color: onTap == null
                          ? AppColors.hint
                          : selected
                          ? AppColors.text
                          : AppColors.muted,
                      fontSize: 15,
                      fontWeight: selected ? FontWeight.w600 : FontWeight.w400,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
