// Pass through Flutter's machine protocol; watch only the PID printed by our runner.
const { spawn } = require('node:child_process');
const path = require('node:path');
const fs = require('node:fs');
const flutter = process.env.FLUTTER_TOOL || process.env.PATH.split(path.delimiter)
  .map(dir => path.join(dir, 'flutter.bat')).find(file => fs.existsSync(file));
if (!flutter) throw new Error('flutter.bat is missing from PATH');
const child = spawn(flutter, process.argv.slice(2), { shell: true, windowsHide: true });
let buffer = '', watcher, stopping = false;
function stop() {
  if (stopping) return;
  stopping = true;
  if (watcher) watcher.kill();
  // This process tree belongs to this launch. Do not kill other Flutter sessions.
  spawn('taskkill', ['/PID', String(child.pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore' });
}
child.stdout.on('data', data => {
  process.stdout.write(data);
  buffer += data.toString();
  const lines = buffer.split('\n');
  buffer = lines.pop();
  for (const line of lines) {
    const match = /scoliosis\.process=(\d+)/.exec(line);
    if (!match || watcher) continue;
    watcher = spawn('powershell.exe', ['-NoProfile', '-Command',
      `Wait-Process -Id ${match[1]} -ErrorAction SilentlyContinue`],
      { windowsHide: true, stdio: 'ignore' });
    watcher.on('exit', stop);
  }
});
child.stderr.pipe(process.stderr);
process.stdin.pipe(child.stdin);
child.stdin.on('error', () => {});
child.on('error', error => { console.error(error.message); process.exit(1); });
child.on('exit', code => {
  if (watcher) watcher.kill();
  process.exit(stopping ? 0 : (code ?? 1));
});
process.on('SIGINT', stop);
process.on('SIGTERM', stop);
process.stdout.on('error', stop);
process.stderr.on('error', stop);
