@echo off
node "%~dp0flutter_session.cjs" %*
