import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:scoliosis_flutter/audio/name_speaker.dart';

// Real Windows plugin acceptance entry point, isolated from production data.
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MaterialApp(home: Scaffold(body: Text('Windows 语音与退出验收'))));
  WidgetsBinding.instance.addPostFrameCallback((_) => unawaited(check()));
}

Future<void> check() async {
  if (const bool.fromEnvironment('SMOKE_HOLD')) {
    stdout.writeln('WINDOWS_SMOKE READY_FOR_FORCED_EXIT');
    return;
  }
  final speaker = WindowsSapiSpeaker();
  try {
    await speaker.speak('首次电脑叫号试听');
    stdout.writeln('WINDOWS_SMOKE first_speech_started');
    await Future<void>.delayed(const Duration(seconds: 2));
    await Future.wait([speaker.speak('下一位学生'), speaker.stop()]);
    stdout.writeln('WINDOWS_SMOKE concurrent_speech_stop');
    await speaker.speak('完成当前班级的拍摄');
    await Future<void>.delayed(const Duration(seconds: 2));
    await speaker.stop();
    stdout.writeln('WINDOWS_SMOKE PASS');
  } catch (error, stack) {
    stderr.writeln('WINDOWS_SMOKE FAIL $error\n$stack');
  } finally {
    await const MethodChannel(
      'scoliosis/window',
    ).invokeMethod<void>('approveClose');
  }
}
