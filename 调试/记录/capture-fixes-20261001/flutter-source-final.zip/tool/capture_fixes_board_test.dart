import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:scoliosis_flutter/app/app_controller.dart';
import 'package:scoliosis_flutter/audio/name_speaker.dart';
import 'package:scoliosis_flutter/net/device_query.dart';
import 'package:scoliosis_flutter/roster/roster.dart';
import 'package:scoliosis_flutter/roster/student.dart';

const adb = 'D:/SoftWare/Android_Studio_SDK/platform-tools/adb.exe';
const deviceId = 'CAM-000123';
final address = InternetAddress('192.168.101.3');

class Speaker implements NameSpeaker {
  final phrases = <String>[];
  @override
  Future<void> speak(String text) async {
    phrases.add(text);
  }

  @override
  Future<void> stop() async {}
}

Future<void> mask(int value) async {
  final result = await Process.run(adb, [
    '-s',
    '3253c006806f5194',
    'shell',
    'printf "%s\\n" $value > /opt/instrument/state/buttons.sim.tmp && mv /opt/instrument/state/buttons.sim.tmp /opt/instrument/state/buttons.sim',
  ]);
  if (result.exitCode != 0) throw StateError('${result.stderr}');
}

Future<void> waitFor(bool Function() check, String name) async {
  final limit = DateTime.now().add(const Duration(seconds: 60));
  while (!check()) {
    if (DateTime.now().isAfter(limit)) throw TimeoutException(name);
    await Future<void>.delayed(const Duration(milliseconds: 30));
  }
}

void main() {
  test(
    'real board zero timer, girls queue, skip restoration, single and short retry',
    () async {
      final root = Directory(
        'build/capture-fixes-board-${DateTime.now().millisecondsSinceEpoch}',
      );
      final roster = List.generate(
        5,
        (i) => Student(
          id: 'fix-$i',
          school: '流程回归实板',
          grade: '测试年级',
          klass: '1班',
          studentNo: '${i + 1}',
          name: '测试$i',
          gender: i == 4 ? '男' : '女',
        ),
      );
      await saveMasterRoster(root, roster);
      final speaker = Speaker();
      final app = AppController(root, speaker: speaker);
      final evidence = File('${root.path}/evidence.jsonl');
      Future<void> log(Map<String, Object?> row) async {
        stdout.writeln(jsonEncode(row));
        await evidence.writeAsString(
          '${jsonEncode(row)}\n',
          mode: FileMode.append,
          flush: true,
        );
      }

      String prepared() => app.sessions
          .expand((s) => s.capturePhases.entries)
          .firstWhere((e) => e.value == 'prepared')
          .key;
      Future<void> ready() =>
          waitFor(() => !app.devices.current!.audioBusy, 'audio idle');
      Future<String> record({bool short = false}) async {
        final id = prepared();
        await mask(0);
        await Future<void>.delayed(const Duration(milliseconds: 150));
        await mask(5);
        await waitFor(
          () => app.sessions.any((s) => s.capturePhases[id] == 'recording'),
          'recording',
        );
        expect(app.shot.elapsed, 0);
        expect(app.exitBlocked, true);
        await Future<void>.delayed(Duration(milliseconds: short ? 350 : 3100));
        await mask(0);
        await waitFor(
          () => app.sessions.any((s) => s.captureResults.containsKey(id)),
          'completion',
        );
        await waitFor(
          () =>
              app.sessions.any((s) => s.records.any((r) => r.captureId == id)),
          'file receipt',
        );
        final session = app.sessions.firstWhere(
          (s) => s.captureResults.containsKey(id),
        );
        await log({
          'check': short ? 'short_retry' : 'success',
          'capture_id': id,
          'student': session.records
              .firstWhere((r) => r.captureId == id)
              .student
              ?.id,
          'result': session.captureResults[id],
          'duration_ms': session.captureDurations[id],
          'zero_timer': true,
        });
        return id;
      }

      try {
        await app.initialize(serverPort: 8081);
        await mask(2);
        await Future<void>.delayed(const Duration(milliseconds: 3350));
        await mask(0);
        final snapshot = await queryDevice(
          deviceId,
          address,
          hostId: app.devices.hostId,
          sequence: 1,
        );
        expect(snapshot, isNotNull);
        expect(snapshot!['paired_host_id'], '');
        app.devices.noteUdp(deviceId, 'regression', address.address);
        app.devices.noteQueryReply(deviceId, snapshot);
        await app.pair(deviceId);
        await waitFor(() => app.devices.currentReady, 'pair ready');
        await ready();
        app
          ..schoolFilter = roster[0].school
          ..gradeFilter = roster[0].grade
          ..classFilter = roster[0].klass
          ..selectedStudentId = roster[0].id;
        app.setCaptureGender(CaptureGender.female);
        expect(await app.startCapture(), isNull);
        await Future<void>.delayed(const Duration(seconds: 2));
        expect(app.shot.elapsed, 0);
        expect(app.shot.phase, ShotPhase.waiting);
        expect(app.historyFor(roster[0].id), isEmpty);
        app.selectStudent(roster[3].id);
        await app.setSkipped(app.preparedStudent!.id, true);
        expect(app.preparedStudent!.id, roster[1].id);
        await app.setSkipped(roster[0].id, false);
        await app.setSkipped(roster[2].id, true);
        await app.setSkipped(roster[2].id, false);
        app.setCaptureGender(CaptureGender.male);
        for (final i in [1, 2, 3, 0]) {
          await waitFor(
            () => app.preparedStudent?.id == roster[i].id,
            'expected girl $i',
          );
          app.selectStudent(roster[i].id);
          await record();
        }
        await waitFor(() => !app.capturePermission, 'end class gate');
        expect(speaker.phrases.last, '完成测试年级1班4人的拍摄，跳过0人');
        expect(app.savedCount(roster[4]), 0);
        await log({
          'check': 'girls_fixed_queue_and_class_end',
          'phrases': speaker.phrases,
        });

        app.setMode(CaptureMode.single);
        app.selectStudent(roster[4].id);
        await ready();
        expect(await app.startCapture(), isNull);
        await waitFor(
          () => speaker.phrases.last == roster[4].name,
          'single first speech',
        );
        final count = speaker.phrases.length;
        await record();
        await waitFor(
          () => app.sessions.any(
            (s) => s.capturePhases.values.contains('prepared'),
          ),
          'single prepare',
        );
        expect(app.preparedStudent!.id, roster[4].id);
        expect(speaker.phrases.length, count);
        final shortId = await record(short: true);
        await waitFor(
          () => speaker.phrases.last == '${roster[4].name}，请重新拍摄',
          'retry speech',
        );
        expect(prepared(), isNot(shortId));
        expect(app.preparedStudent!.id, roster[4].id);
        await log({
          'check': 'single_no_repeat_and_short_new_id',
          'phrases': speaker.phrases,
          'root': root.absolute.path,
        });
      } finally {
        await mask(0);
        await app.stopCapture();
        if (app.devices.paired.contains(deviceId)) await app.unpair(deviceId);
        await app.shutdown();
        app.dispose();
      }
    },
    timeout: const Timeout(Duration(minutes: 5)),
  );
}
