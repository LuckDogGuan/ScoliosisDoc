import 'package:flutter/material.dart';

import 'app_theme.dart';
import '../app/error_log.dart';

class VolumeDialog extends StatefulWidget {
  const VolumeDialog({
    super.key,
    required this.deviceId,
    required this.initialVolume,
    required this.onConfirm,
    this.onTest,
  });

  final String deviceId;
  final int initialVolume;
  final Future<void> Function(int volume) onConfirm;
  final Future<void> Function(int volume)? onTest;

  @override
  State<VolumeDialog> createState() => _VolumeDialogState();
}

class _VolumeDialogState extends State<VolumeDialog> {
  late double _currentVol;
  bool _saving = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _currentVol = widget.initialVolume.clamp(0, 30).toDouble();
  }

  @override
  Widget build(BuildContext context) {
    final volInt = _currentVol.round();
    final pct = (volInt * 100 / 30).round();

    return AlertDialog(
      title: Text('调整仪器喇叭音量（${widget.deviceId}）'),
      content: SizedBox(
        width: 380,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Expanded(child: Text('音量等级：', style: AppType.muted)),
                Text(
                  '$volInt / 30 ($pct%)',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: AppColors.primary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                const Icon(Icons.volume_mute, size: 20, color: AppColors.muted),
                Expanded(
                  child: Slider(
                    value: _currentVol,
                    min: 0,
                    max: 30,
                    divisions: 30,
                    label: '$volInt',
                    onChanged: _saving
                        ? null
                        : (val) => setState(() => _currentVol = val),
                  ),
                ),
                const Icon(Icons.volume_up, size: 20, color: AppColors.primary),
              ],
            ),
            if (_error != null)
              Text(_error!, style: const TextStyle(color: AppColors.danger)),
            const SizedBox(height: 8),
            Text(
              '* 保存后将永久写入仪器内部存储，关机重启依然保持。',
              style: AppType.muted.copyWith(fontSize: 12),
            ),
          ],
        ),
      ),
      actions: [
        if (widget.onTest != null)
          TextButton.icon(
            onPressed: _saving
                ? null
                : () async {
                    setState(() {
                      _saving = true;
                      _error = null;
                    });
                    try {
                      await widget.onTest!(volInt);
                    } catch (error, stack) {
                      await ErrorLog.write('VolumeDialog.test', error, stack);
                      if (mounted) setState(() => _error = '$error');
                    } finally {
                      if (mounted) setState(() => _saving = false);
                    }
                  },
            icon: const Icon(Icons.volume_up_rounded),
            label: const Text('测试喇叭'),
          ),
        TextButton(
          onPressed: _saving ? null : () => Navigator.pop(context),
          child: const Text('取消'),
        ),
        FilledButton(
          onPressed: _saving
              ? null
              : () async {
                  setState(() => _saving = true);
                  try {
                    await widget.onConfirm(volInt);
                    if (context.mounted) Navigator.pop(context);
                  } catch (error, stack) {
                    await ErrorLog.write('VolumeDialog.save', error, stack);
                    if (mounted) {
                      setState(() {
                        _saving = false;
                        _error = '$error';
                      });
                    }
                  }
                },
          child: _saving
              ? const SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white,
                  ),
                )
              : const Text('确认保存并应用'),
        ),
      ],
    );
  }
}
