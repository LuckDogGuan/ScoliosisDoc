import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../app/app_controller.dart';
import '../../roster/roster_sort.dart';
import '../../roster/student.dart';
import '../app_theme.dart';
import '../widgets.dart';

class CapturePage extends StatefulWidget {
  const CapturePage({super.key, required this.controller});

  final AppController controller;

  @override
  State<CapturePage> createState() => _CapturePageState();
}

class _CapturePageState extends State<CapturePage> {
  final search = TextEditingController();
  String query = '';

  AppController get controller => widget.controller;

  @override
  void dispose() {
    search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final student = controller.selectedStudent;
    final device = controller.devices.current;
    final ready = controller.devices.currentReady;
    final shot = controller.shot;
    final ordered = controller.classFilter == null
        ? <Student>[]
        : controller.classStudents;
    final sequenceStudent = ordered
        .where((item) => item.id == student?.id)
        .firstOrNull;
    final index = sequenceStudent == null
        ? -1
        : ordered.indexWhere((item) => item.id == sequenceStudent.id);
    return Padding(
      padding: AppSpace.page,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          PageHeading(title: '拍摄', subtitle: _crumb(device?.id, ready)),
          // 设备未就绪时，仅在页面顶部显示一个 JumpBanner，不重复提示
          if (!ready) ...[
            const SizedBox(height: 10),
            JumpBanner(
              message: '仪器未配对或当前离线',
              action: '去设备页',
              onPressed: () => controller.go(AppPage.device),
            ),
          ],
          if (controller.capturePermission &&
              controller.preparedStudent != null)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Text(
                '${controller.recordingBusy ? '当前任务' : '当前准备'}：${controller.preparedStudent!.name} · ${controller.recordingBusy ? '录制和收尾期间可以查看名单，不能替换任务' : '左右键长按 1.5 秒开录；点击名单只查看信息'}',
                style: AppType.muted,
              ),
            ),
          const SizedBox(height: 12),
          // 过滤栏：学校/年级/班级 + 顶序/单独模式（顺序与名单页保持一致）
          Wrap(
            spacing: 8,
            runSpacing: 8,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              ScopeMenus(controller: controller),
              SegmentedButton<RosterSort>(
                segments: [
                  for (final item in RosterSort.values)
                    ButtonSegment(value: item, label: Text(item.label)),
                ],
                selected: {controller.sort},
                onSelectionChanged: (next) => controller.setSort(next.first),
              ),
              SegmentedButton<GenderOrder>(
                segments: [
                  for (final item in GenderOrder.values)
                    ButtonSegment(value: item, label: Text(item.label)),
                ],
                selected: {controller.genderOrder},
                onSelectionChanged: (next) =>
                    controller.setGenderOrder(next.first),
              ),
              SegmentedButton<CaptureMode>(
                segments: const [
                  ButtonSegment(
                    value: CaptureMode.sequence,
                    label: Text('顺序模式'),
                    icon: Icon(Icons.format_list_numbered_rounded, size: 15),
                  ),
                  ButtonSegment(
                    value: CaptureMode.single,
                    label: Text('单独模式'),
                    icon: Icon(Icons.person_search_rounded, size: 15),
                  ),
                ],
                selected: {controller.captureMode},
                onSelectionChanged: (next) => controller.setMode(next.first),
              ),
            ],
          ),
          const SizedBox(height: 6),
          // 当前顺序说明，显示在过滤栏下方
          if (controller.classFilter != null)
            _OrderNote(controller: controller),
          const SizedBox(height: 8),
          Expanded(
            child: controller.captureMode == CaptureMode.sequence
                ? _Sequence(
                    controller: controller,
                    student: sequenceStudent,
                    index: index,
                    total: ordered.length,
                    shot: shot,
                    ordered: ordered,
                    onMessage: _toast,
                  )
                : _Single(
                    controller: controller,
                    query: query,
                    search: search,
                    onQuery: (value) => setState(() => query = value),
                    shot: shot,
                    onMessage: _toast,
                  ),
          ),
        ],
      ),
    );
  }

  String _crumb(String? deviceId, bool ready) {
    final school = controller.schoolFilter ?? '未选';
    final grade = controller.gradeFilter ?? '—';
    final klass = controller.classFilter ?? '—';
    final deviceStr = deviceId == null
        ? '未配对'
        : '$deviceId ${ready ? '已就绪' : '不在线'}';
    return '$school  $grade  $klass    $deviceStr';
  }

  void _toast(String? message) {
    if (message == null || !mounted) return;
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }
}

// 当前顺序说明条
class _OrderNote extends StatelessWidget {
  const _OrderNote({required this.controller});

  final AppController controller;

  @override
  Widget build(BuildContext context) {
    final sort = controller.sort;
    final gender = controller.genderOrder;
    final hasWarning = controller.numericWarning != null;
    return Row(
      children: [
        Icon(Icons.sort_rounded, size: 13, color: AppColors.hint),
        const SizedBox(width: 4),
        Text(
          '顺序：${sort.label} · ${gender.label}',
          style: const TextStyle(fontSize: 12, color: AppColors.muted),
        ),
        if (hasWarning) ...[
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              controller.numericWarning!,
              style: const TextStyle(fontSize: 12, color: AppColors.warning),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ],
    );
  }
}

class _Sequence extends StatelessWidget {
  const _Sequence({
    required this.controller,
    required this.student,
    required this.index,
    required this.total,
    required this.shot,
    required this.ordered,
    required this.onMessage,
  });

  final AppController controller;
  final Student? student;
  final int index;
  final int total;
  final ShotSnapshot shot;
  final List<Student> ordered;
  final void Function(String?) onMessage;

  @override
  Widget build(BuildContext context) {
    final history = student == null
        ? <RecordRow>[]
        : controller.historyFor(student!.id);
    return SoftCard(
      padding: EdgeInsets.zero,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            flex: 5,
            child: Padding(
              padding: AppSpace.cardPad,
              child: student == null
                  ? Align(
                      alignment: Alignment.topLeft,
                      child: Text(
                        '选择学校、年级和班级后，从左侧名单点选学生开始拍摄。',
                        style: AppType.muted,
                      ),
                    )
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          total == 0
                              ? '这个班还没有学生'
                              : '本班第 ${index + 1} / $total 位',
                          style: AppType.muted,
                        ),
                        const SizedBox(height: 6),
                        Text(
                          '学号 ${student!.studentNo}',
                          style: const TextStyle(
                            fontSize: 15,
                            color: AppColors.muted,
                          ),
                        ),
                        Text(student!.name, style: AppType.studentName),
                        Text(
                          student!.birthDate == null
                              ? student!.gender
                              : '${student!.gender}  ·  ${student!.ageAt(DateTime.now())}',
                          style: const TextStyle(
                            fontSize: 15,
                            color: AppColors.muted,
                          ),
                        ),
                        const SizedBox(height: 18),
                        _ShotBar(shot: shot),
                        const SizedBox(height: 14),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            FilledButton.icon(
                              onPressed: controller.recordingBusy
                                  ? null
                                  : () async => onMessage(
                                      await controller.startCapture(),
                                    ),
                              icon: const Icon(
                                Icons.photo_camera_rounded,
                                size: 17,
                              ),
                              label: const Text('从此位置开始拍摄'),
                            ),
                            if (controller.capturePermission)
                              OutlinedButton.icon(
                                onPressed: () async =>
                                    onMessage(await controller.stopCapture()),
                                icon: const Icon(Icons.stop_rounded, size: 17),
                                label: const Text('停止拍摄许可'),
                              ),
                            OutlinedButton.icon(
                              onPressed: () async => onMessage(
                                await controller.speakCurrentName(),
                              ),
                              icon: const Icon(
                                Icons.volume_up_rounded,
                                size: 16,
                              ),
                              label: const Text('电脑叫号试听'),
                            ),
                            if (shot.phase == ShotPhase.saved ||
                                shot.phase == ShotPhase.leftOnDevice ||
                                shot.phase == ShotPhase.uploading)
                              OutlinedButton.icon(
                                onPressed: controller.captureBusy
                                    ? null
                                    : controller.goNext,
                                icon: const Icon(
                                  Icons.arrow_forward_rounded,
                                  size: 16,
                                ),
                                label: const Text('下一位'),
                              ),
                            OutlinedButton.icon(
                              onPressed: controller.captureBusy
                                  ? null
                                  : () async {
                                      await controller.setSkipped(
                                        student!.id,
                                        !controller.isSkipped(student!.id),
                                      );
                                      if (controller.isSkipped(student!.id)) {
                                        await controller.goNext();
                                      }
                                    },
                              icon: Icon(
                                controller.isSkipped(student!.id)
                                    ? Icons.undo_rounded
                                    : Icons.skip_next_rounded,
                                size: 16,
                              ),
                              label: Text(
                                controller.isSkipped(student!.id)
                                    ? '清除跳过'
                                    : '跳过并标记',
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),
                        Text(
                          '历史拍摄（${history.length}）',
                          style: AppType.cardTitle,
                        ),
                        const SizedBox(height: 6),
                        Expanded(
                          child: history.isEmpty
                              ? Text('暂无历史拍摄', style: AppType.muted)
                              : ListView.builder(
                                  itemCount: history.length,
                                  itemBuilder: (context, i) {
                                    final row = history[i];
                                    return Padding(
                                      padding: const EdgeInsets.symmetric(
                                        vertical: 4,
                                      ),
                                      child: Text(
                                        '${DateFormat('yyyy-MM-dd HH:mm').format(row.time)}  ${row.status}  ${row.deviceId}',
                                        style: AppType.muted,
                                      ),
                                    );
                                  },
                                ),
                        ),
                      ],
                    ),
            ),
          ),
          Container(width: 0.5, color: AppColors.line),
          Expanded(
            flex: 3,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const Padding(
                  padding: EdgeInsets.fromLTRB(14, 12, 14, 6),
                  child: Text('本班名单', style: AppType.cardTitle),
                ),
                Expanded(
                  child: ordered.isEmpty
                      ? Padding(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                            vertical: 8,
                          ),
                          child: Text(
                            controller.classFilter == null
                                ? '选择班级'
                                : '这个班还没有学生。',
                            style: AppType.muted,
                          ),
                        )
                      : ListView.builder(
                          itemCount: ordered.length,
                          itemBuilder: (context, i) {
                            final item = ordered[i];
                            final selected = item.id == student?.id;
                            return InkWell(
                              onTap: () => controller.selectStudent(item.id),
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 14,
                                  vertical: 8,
                                ),
                                decoration: BoxDecoration(
                                  color: selected
                                      ? AppColors.primary.withValues(
                                          alpha: 0.06,
                                        )
                                      : null,
                                  border: Border(
                                    left: BorderSide(
                                      color: selected
                                          ? AppColors.primary
                                          : Colors.transparent,
                                      width: 3,
                                    ),
                                    bottom: BorderSide(
                                      color: AppColors.line.withValues(
                                        alpha: 0.5,
                                      ),
                                      width: 0.5,
                                    ),
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            item.name,
                                            style: TextStyle(
                                              fontSize: 14,
                                              fontWeight: selected
                                                  ? FontWeight.w700
                                                  : FontWeight.w500,
                                              color: selected
                                                  ? AppColors.primary
                                                  : AppColors.text,
                                            ),
                                          ),
                                          Text(
                                            '${item.studentNo}  ${item.gender}',
                                            style: AppType.muted,
                                          ),
                                        ],
                                      ),
                                    ),
                                    Text(
                                      _status(controller, item),
                                      style: TextStyle(
                                        fontSize: 12,
                                        color: _statusColor(controller, item),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _status(AppController c, Student item) {
    if (c.isSkipped(item.id)) return '已跳过';
    final saved = c.savedCount(item);
    if (!item.profileComplete) return '资料缺项';
    if (saved == 0) return '待拍';
    return '已拍 $saved 次';
  }

  Color _statusColor(AppController c, Student item) {
    if (c.isSkipped(item.id)) return AppColors.warning;
    final saved = c.savedCount(item);
    if (!item.profileComplete) return AppColors.warning;
    if (saved == 0) return AppColors.muted;
    return AppColors.success;
  }
}

class _Single extends StatelessWidget {
  const _Single({
    required this.controller,
    required this.query,
    required this.search,
    required this.onQuery,
    required this.shot,
    required this.onMessage,
  });

  final AppController controller;
  final String query;
  final TextEditingController search;
  final ValueChanged<String> onQuery;
  final ShotSnapshot shot;
  final void Function(String?) onMessage;

  @override
  Widget build(BuildContext context) {
    final results = controller.searchStudents(query);
    final selected = controller.selectedStudent;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            Expanded(
              child: TextField(
                controller: search,
                decoration: const InputDecoration(
                  hintText: '全校搜索姓名或学号',
                  prefixIcon: Icon(Icons.search_rounded, size: 18),
                ),
                onSubmitted: onQuery,
                onChanged: (value) => onQuery(value),
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Expanded(
          child: SoftCard(
            padding: EdgeInsets.zero,
            child: query.isEmpty
                ? Center(child: Text('输入姓名或学号搜索', style: AppType.muted))
                : results.isEmpty
                ? Center(child: Text('无匹配结果', style: AppType.muted))
                : ListView(
                    children: [
                      for (final student in results)
                        ListTile(
                          leading: Icon(
                            student.id == selected?.id
                                ? Icons.radio_button_checked_rounded
                                : Icons.radio_button_off_rounded,
                            color: student.id == selected?.id
                                ? AppColors.primary
                                : AppColors.hint,
                            size: 18,
                          ),
                          title: Text(
                            '${student.name}  ${student.studentNo}',
                            style: const TextStyle(fontSize: 14),
                          ),
                          subtitle: Text(
                            '${student.school} · ${student.grade}${classLabel(student.klass)}  ${student.gender}',
                            style: const TextStyle(fontSize: 12),
                          ),
                          trailing: Text(
                            controller.savedCount(student) == 0
                                ? '待拍'
                                : '已拍 ${controller.savedCount(student)} 次',
                            style: TextStyle(
                              fontSize: 12,
                              color: controller.savedCount(student) == 0
                                  ? AppColors.muted
                                  : AppColors.success,
                            ),
                          ),
                          onTap: () => controller.selectStudent(student.id),
                        ),
                    ],
                  ),
          ),
        ),
        const SizedBox(height: 10),
        SoftCard(
          child: selected == null
              ? Text('搜索后点选学生。拍完留在当前，不自动跳走。', style: AppType.muted)
              : Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            selected.name,
                            style: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w700,
                              color: AppColors.text,
                            ),
                          ),
                          Text(
                            '${selected.studentNo} · ${selected.school}${selected.grade}${classLabel(selected.klass)}  ${selected.gender}'
                            '${selected.birthDate == null ? '' : ' · ${selected.ageAt(DateTime.now())}'}',
                            style: AppType.muted,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(child: _ShotBar(shot: shot)),
                    const SizedBox(width: 12),
                    FilledButton.icon(
                      onPressed: controller.recordingBusy
                          ? null
                          : () async =>
                                onMessage(await controller.startCapture()),
                      icon: const Icon(Icons.photo_camera_rounded, size: 17),
                      label: const Text('拍摄此学生'),
                    ),
                    if (controller.capturePermission) ...[
                      const SizedBox(width: 8),
                      OutlinedButton.icon(
                        onPressed: () async =>
                            onMessage(await controller.stopCapture()),
                        icon: const Icon(Icons.stop_rounded, size: 17),
                        label: const Text('停止拍摄许可'),
                      ),
                    ],
                    const SizedBox(width: 8),
                    OutlinedButton.icon(
                      onPressed: () async =>
                          onMessage(await controller.speakCurrentName()),
                      icon: const Icon(Icons.volume_up_rounded, size: 16),
                      label: const Text('电脑叫号试听'),
                    ),
                  ],
                ),
        ),
      ],
    );
  }
}

class _ShotBar extends StatelessWidget {
  const _ShotBar({required this.shot});

  final ShotSnapshot shot;

  @override
  Widget build(BuildContext context) {
    final progress = switch (shot.phase) {
      ShotPhase.recording => (shot.elapsed.clamp(0, 60)) / 60,
      ShotPhase.uploading => null,
      ShotPhase.saved => 1.0,
      _ => 0.0,
    };
    final color = switch (shot.phase) {
      ShotPhase.saved => AppColors.success,
      ShotPhase.leftOnDevice => AppColors.warning,
      ShotPhase.failed => AppColors.danger,
      ShotPhase.recording ||
      ShotPhase.finalizing ||
      ShotPhase.uploading ||
      ShotPhase.waiting => AppColors.primary,
      ShotPhase.idle => AppColors.hint,
    };
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          shot.label,
          style: TextStyle(
            color: color,
            fontSize: 15,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(99),
          child: LinearProgressIndicator(
            minHeight: 6,
            value: progress,
            backgroundColor: AppColors.line,
            valueColor: AlwaysStoppedAnimation<Color>(color),
          ),
        ),
      ],
    );
  }
}
