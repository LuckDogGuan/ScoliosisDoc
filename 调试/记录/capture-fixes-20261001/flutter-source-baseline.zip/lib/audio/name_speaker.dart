import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';

/// 电脑扬声器上的一句叫号。板端不走这里。
abstract class NameSpeaker {
  Future<void> speak(String text);
  Future<void> stop();
}

/// Windows 离线 SAPI。优先 Microsoft Huihui，否则任一中文音色。
class WindowsSapiSpeaker implements NameSpeaker {
  FlutterTts? _tts;

  Future<void> _ensure() async {
    if (_tts != null) return;
    if (kIsWeb || !Platform.isWindows) {
      throw UnsupportedError('姓名播报只在 Windows 电脑上播放');
    }
    final tts = FlutterTts();
    await tts.awaitSpeakCompletion(true);
    await tts.setVolume(1);
    await tts.setSpeechRate(0.5);
    await tts.setPitch(1);
    var applied = false;
    final chosen = _chineseVoice(await tts.getVoices);
    if (chosen != null && await tts.setVoice(chosen) == 1) {
      applied = true;
    }
    if (!applied && await tts.setLanguage('zh-CN') == 1) {
      applied = true;
    }
    if (!applied) {
      throw StateError('没有可用的中文离线语音。请在 Windows 设置中安装中文语音，例如 Microsoft Huihui。');
    }
    _tts = tts;
  }

  Map<String, String>? _chineseVoice(dynamic voices) {
    if (voices is! List) return null;
    Map<String, String>? chinese;
    for (final item in voices) {
      if (item is! Map) continue;
      final name = '${item['name']}';
      final locale = '${item['locale']}';
      if (name.isEmpty || locale.isEmpty) continue;
      final voice = {'name': name, 'locale': locale};
      if (name.toLowerCase().contains('huihui')) return voice;
      final normalized = locale.toLowerCase().replaceAll('_', '-');
      if (normalized.startsWith('zh') && chinese == null) chinese = voice;
    }
    return chinese;
  }

  @override
  Future<void> speak(String text) async {
    await _ensure();
    final tts = _tts;
    if (tts == null) return;
    await tts.stop();
    await tts.speak(text);
  }

  @override
  Future<void> stop() async {
    final tts = _tts;
    if (tts == null) return;
    await tts.stop();
  }
}
